
from pathlib import Path
import time
import cv2
import numpy as np
from PIL import ImageGrab


def buscar_plantilla_pantalla(template_path: Path, threshold: float = 0.75, timeout: float = 10.0, poll: float = 0.3):

    template_path = Path(template_path)
    if not template_path.exists():
        return None

    template = cv2.imread(str(template_path))
    if template is None:
        return None

    template_gray = cv2.cvtColor(template, cv2.COLOR_BGR2GRAY)
    th, tw = template_gray.shape[::-1]

    end_time = time.time() + timeout
    while time.time() < end_time:
        try:
            img = np.array(ImageGrab.grab())
            screen = cv2.cvtColor(img, cv2.COLOR_RGB2BGR)
            screen_gray = cv2.cvtColor(screen, cv2.COLOR_BGR2GRAY)

            res = cv2.matchTemplate(screen_gray, template_gray, cv2.TM_CCOEFF_NORMED)
            min_val, max_val, min_loc, max_loc = cv2.minMaxLoc(res)

            if max_val >= threshold:
                top_left = max_loc
                center_x = int(top_left[0] + tw / 2)
                center_y = int(top_left[1] + th / 2)
                return center_x, center_y

        except Exception:
            pass

        time.sleep(poll)

    return None


__all__ = ["buscar_plantilla_pantalla"]
