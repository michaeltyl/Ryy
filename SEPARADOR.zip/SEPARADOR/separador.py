
from pathlib import Path
import logging
import sys
import time
import pandas as pd
import os

# Intentar imports relativos (cuando se ejecuta como módulo)
# Si falla, usar imports absolutos (cuando se ejecuta directamente)
try:
    from .controlador import ControladorApp
    from .util_imagen import buscar_plantilla_pantalla
except ImportError:
    # Agregar el directorio actual al path si se ejecuta directamente
    sys.path.insert(0, str(Path(__file__).parent))
    from controlador import ControladorApp
    from util_imagen import buscar_plantilla_pantalla


SCRIPT_DIR = Path(__file__).parent
PROJECT_DIR = SCRIPT_DIR
IMG_DIR = PROJECT_DIR / "IMG"
DATA_FILE = PROJECT_DIR / "DATA.xlsx"
PASSWORD_FILE = PROJECT_DIR / "contraseña.txt"
SHORTCUT_PATH = PROJECT_DIR / "Actualiza RSIRAT.lnk"


def configurar_logger():
    logger = logging.getLogger("robot_rsirat")
    logger.setLevel(logging.INFO)
    ch = logging.StreamHandler(sys.stdout)
    ch.setLevel(logging.INFO)
    formatter = logging.Formatter('%(asctime)s - %(levelname)s - %(message)s')
    ch.setFormatter(formatter)
    logger.addHandler(ch)
    return logger


def cargar_contraseña():
    if PASSWORD_FILE.exists():
        return PASSWORD_FILE.read_text(encoding='utf-8').strip()
    return ""


def normalizar_dependencia(dependencia: str) -> str:
    """
    Normaliza el código de dependencia a su nombre completo.
    
    Entrada: "21", "021", "0021", "23", "023", "0023"
    Salida:  "0021 I.R. Lima - PRICO" o "0023 I.R. Lima - MEPECO"
    """
    dep_code = str(dependencia).strip()
    dep_map = {
        "21": "0021 I.R. Lima - PRICO",
        "021": "0021 I.R. Lima - PRICO",
        "0021": "0021 I.R. Lima - PRICO",
        "23": "0023 I.R. Lima - MEPECO",
        "023": "0023 I.R. Lima - MEPECO",
        "0023": "0023 I.R. Lima - MEPECO",
    }
    return dep_map.get(dep_code, dep_code)  # Retorna normalizado o el original si no existe


def main():
    logger = configurar_logger()
    logger.info("Iniciando robot (versión en español) — hasta digitación de expediente")

    if not DATA_FILE.exists():
        logger.error(f"No se encontró {DATA_FILE}")
        return 1

    df = pd.read_excel(DATA_FILE, dtype=str, keep_default_na=False)
    requeridas = ["RUC", "ACUMULADOR", "NRO ACUM", "DEPENDENCIA", "RESULTADO"]
    faltantes = [c for c in requeridas if c not in df.columns]
    if faltantes:
        logger.error(f"Faltan columnas en {DATA_FILE}: {faltantes}")
        return 1

    contraseña = cargar_contraseña()
    controlador = ControladorApp(logger, img_dir=IMG_DIR, cache_path=PROJECT_DIR / "coords_cache.json")

    if not controlador.open_app(shortcut_path=SHORTCUT_PATH):
        logger.warning("No se pudo enfocar la aplicación; continuar intentando")

    for idx, fila in df.iterrows():
        logger.info(f"Procesando fila {idx+2} - RUC={fila['RUC']} ACUM={fila['ACUMULADOR']} DEP={fila['DEPENDENCIA']}")

        # Normalizar dependencia
        dependencia_normalizada = normalizar_dependencia(fila['DEPENDENCIA'])
        logger.info(f"Dependencia normalizada: {dependencia_normalizada}")

        # 1) Login
        exitoso = controlador.login(dependencia_normalizada, contraseña)
        if not exitoso:
            logger.error("Login falló; marcar y continuar con siguiente fila")
            continue

        # 2) Cobranza Coactiva (002.png)
        if not controlador.click_image('002.png', timeout=15.0, poll=0.3):
            logger.error("No se pudo clickear Cobranza Coactiva (002.png)")
            continue

        time.sleep(0.5)

        # 3) Exp. Cob. Coactiva - Individual (003.png) x4
        if not controlador.click_image('003.png', clicks=4, timeout=10.0, poll=0.3):
            logger.error("No se pudo clickear Exp.Cob. Coactiva - Individual (003.png)")
            continue

        time.sleep(0.5)

        # 4) Click referencia 004.png y digitar ACUMULADOR
        if not controlador.click_image_and_type('004.png', fila['ACUMULADOR'], timeout=10.0, poll=0.3):
            logger.error("No se pudo ubicar campo de expediente (004.png) o digitar")
            continue

        logger.info(f"Fila {idx+2}: digitación completada (ACUM={fila['ACUMULADOR']})")
        time.sleep(0.5)

    logger.info("Proceso finalizado (hasta digitación)")
    return 0


if __name__ == '__main__':
    sys.exit(main())
