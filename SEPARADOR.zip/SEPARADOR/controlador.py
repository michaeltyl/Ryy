
from pathlib import Path
import time
import logging
import pyautogui
import os
from pywinauto import Desktop

# Intentar imports relativos (cuando se ejecuta como módulo)
# Si falla, usar imports absolutos (cuando se ejecuta directamente)
try:
    from .util_imagen import buscar_plantilla_pantalla
    from .cache_coordenadas import CacheCoordenadas
except ImportError:
    import sys
    sys.path.insert(0, str(Path(__file__).parent))
    from util_imagen import buscar_plantilla_pantalla
    from cache_coordenadas import CacheCoordenadas


class ControladorApp:
    """Controlador ligero de la aplicación SIRAT."""

    def __init__(self, logger: logging.Logger = None, img_dir: Path = None, cache_path: Path = None):
        self.logger = logger or logging.getLogger(__name__)
        self.img_dir = Path(img_dir) if img_dir else Path.cwd() / "IMG"
        self.coords_cache = CacheCoordenadas(cache_path)

    def open_app(self, shortcut_path: Path = None) -> bool:
        """Intenta lanzar la aplicación si se proporciona shortcut_path, luego enfoca la ventana SIRAT.
        
        Si shortcut_path se proporciona:
        1. Ejecuta el atajo "Actualiza RSIRAT.lnk"
        2. Espera a que aparezca la ventana SIRAT
        
        Luego intenta enfocar la ventana SIRAT.
        Retorna True si pudo intentar (no garantiza login).
        """
        try:
            # Si se proporciona shortcut, intentar ejecutarlo
            if shortcut_path:
                if Path(shortcut_path).exists():
                    try:
                        self.logger.info(f"Ejecutando aplicación desde: {shortcut_path}")
                        os.startfile(str(shortcut_path))
                        time.sleep(2.0)  # Esperar a que se lance la app
                    except Exception as e:
                        self.logger.warning(f"No se pudo ejecutar shortcut: {e}")
                else:
                    self.logger.warning(f"Shortcut no encontrado: {shortcut_path}")
            
            # Intentar enfocar la ventana SIRAT
            desktop = Desktop(backend="uia")
            try:
                win = desktop.window(title_re=".*SIRAT.*")
                if win.exists(timeout=5):
                    try:
                        win.set_focus()
                    except Exception:
                        pass
                    time.sleep(0.5)
                    return True
            except Exception:
                pass
            try:
                desktop.active().set_focus()
                time.sleep(0.3)
            except Exception:
                pass
            return True
        except Exception as e:
            self.logger.error(f"Error en open_app: {e}")
            return False

    def detect_password_error(self, timeout: float = 2.0) -> bool:
        """
        Detecta si hay un mensaje de error de contraseña en la ventana SIRAT.
        
        Busca palabras clave en los textos de los controles:
        - "no puede ser accedido"
        - "estimado usuario"
        - "error en las credenciales"
        - "error numero"
        
        Retorna True si detecta error, False si no.
        """
        try:
            self.logger.info("Verificando si hay mensaje de error de contraseña...")
            desktop = Desktop(backend="uia")
            
            end_time = time.time() + timeout
            while time.time() < end_time:
                try:
                    win = desktop.window(title_re=".*SIRAT.*")
                    if win.exists(timeout=1):
                        for desc in win.descendants():
                            try:
                                txt = desc.window_text() or ""
                                if txt.strip():
                                    txt_lower = txt.lower()
                                    palabras_clave = [
                                        "no puede ser accedido",
                                        "estimado usuario",
                                        "error en las credenciales",
                                        "error numero",
                                        "credenciales"
                                    ]
                                    if any(palabra in txt_lower for palabra in palabras_clave):
                                        self.logger.error(f"Mensaje de error detectado: {txt}")
                                        return True
                            except Exception:
                                continue
                except Exception:
                    pass
                time.sleep(0.25)
            
            return False
        except Exception as e:
            self.logger.error(f"Error en detect_password_error: {e}")
            return False

    def login(self, dependencia: str, password: str = "") -> bool:
        """Login: escribe dependencia, TAB, contraseña y ENTER.

        Detecta mensajes de error de contraseña incorrecta.
        Retorna True si login OK, False si login falló o error de contraseña.
        """
        try:
            desktop = Desktop(backend="uia")
            try:
                win = desktop.window(title_re=".*SIRAT.*")
                if not win.exists(timeout=5):
                    self.logger.warning("Ventana SIRAT no encontrada para login")
                    return False
                try:
                    win.set_focus()
                except Exception:
                    pass
            except Exception:
                try:
                    desktop.active().set_focus()
                except Exception:
                    pass

            time.sleep(0.5)
            
            # Digitar dependencia
            self.logger.info(f"Digitando dependencia: {dependencia}")
            self.type_preserve_zeros(str(dependencia))
            
            time.sleep(0.1)
            pyautogui.press('tab')
            time.sleep(0.2)
            
            # Digitar contraseña
            self.logger.info("Digitando contraseña...")
            self.type_preserve_zeros(str(password))
            
            time.sleep(0.1)
            pyautogui.press('return')
            time.sleep(0.5)

            # Verificar si hay error de contraseña
            if self.detect_password_error(timeout=1.5):
                self.logger.error("Contraseña incorrecta detectada. Login falló.")
                return False

            self.logger.info("Login completado exitosamente")
            return True
        except Exception as e:
            self.logger.error(f"Error en login: {e}")
            return False

    def click_image(self, image_name: str, clicks: int = 1, timeout: float = 10.0, poll: float = 0.3) -> bool:
        """Busca `image_name` en `self.img_dir` y hace clic en el centro si la encuentra."""
        try:
            tpl = Path(self.img_dir) / image_name
            encontrado = buscar_plantilla_pantalla(tpl, timeout=timeout, poll=poll)
            if not encontrado:
                self.logger.warning(f"Imagen no encontrada: {tpl}")
                return False
            x, y = encontrado
            for i in range(clicks):
                pyautogui.click(x, y)
                time.sleep(0.02)
            self.logger.info(f"Clic(s) en {image_name}: ({x},{y}) x{clicks}")
            return True
        except Exception as e:
            self.logger.error(f"Error click_image {image_name}: {e}")
            return False

    def click_image_and_type(self, image_name: str, text: str, timeout: float = 10.0, poll: float = 0.3) -> bool:
        ok = self.click_image(image_name, clicks=1, timeout=timeout, poll=poll)
        if not ok:
            return False
        time.sleep(0.3)
        self.type_preserve_zeros(text)
        return True

    def type_preserve_zeros(self, text: str):
        for c in str(text):
            pyautogui.typewrite(c, interval=0.02)
        time.sleep(0.2)


__all__ = ["ControladorApp"]
