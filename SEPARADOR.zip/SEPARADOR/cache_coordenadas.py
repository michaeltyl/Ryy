
import json
from pathlib import Path
from datetime import datetime
from typing import Optional


class CacheCoordenadas:
    def __init__(self, path: Optional[Path] = None):
        self.path = Path(path) if path else None
        self.cache = {}
        if self.path and self.path.exists():
            try:
                with open(self.path, 'r', encoding='utf-8') as f:
                    self.cache = json.load(f)
            except Exception:
                self.cache = {}

    def get(self, key: str, dependencia: str):
        dep_key = f"dep_{dependencia}"
        return self.cache.get(dep_key, {}).get(key)

    def set(self, key: str, dependencia: str, x: int, y: int):
        dep_key = f"dep_{dependencia}"
        if dep_key not in self.cache:
            self.cache[dep_key] = {}
        self.cache[dep_key][key] = {"x": x, "y": y, "ts": datetime.now().isoformat()}
        if self.path:
            try:
                self.path.parent.mkdir(parents=True, exist_ok=True)
                with open(self.path, 'w', encoding='utf-8') as f:
                    json.dump(self.cache, f, indent=2)
            except Exception:
                pass

    def clear(self):
        self.cache = {}
        if self.path:
            try:
                with open(self.path, 'w', encoding='utf-8') as f:
                    json.dump(self.cache, f)
            except Exception:
                pass


__all__ = ["CacheCoordenadas"]
