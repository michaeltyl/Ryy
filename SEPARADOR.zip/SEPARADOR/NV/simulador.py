import tkinter as tk
from tkinter import ttk

DATOS_SIMULADOS = [
    # Expedientes, Tipo, Origen, Saldo_exigible, Saldo_costos, Numero_valores, Numero_embargos
    ("0230060278337", "Acumulado", "Automática", 100, 100, 1, 0),    # No cumple
    ("0230060283757", "Acumulado", "Automática", 30, 20, 1, 0),    # No cumple
    ("0230060306399", "Acumulado", "Automática", 800, 50, 5, 0),   # No cumple
    ("0230060313953", "Acumulado", "Automática", 40, 0, 3, 100),    # No cumple
    ("0230060326862", "Acumulado", "Automática", 0, 0, 1, 0),    # CUMPLE
    ("0230060338087", "Acumulado", "Automática", 240, 10, 1, 0), # No cumple
    ("0230060369958", "Acumulado", "Automática", 0, 0, 2, 0),    # CUMPLE
    ("0230060375162", "Acumulado", "Automática", 0, 0, 1, 0),    # CUMPLE
    ("0230060381860", "Acumulado", "Automática", 850, 0, 1, 2),  # No cumple
    ("0230060384710", "Acumulado", "Automática", 0, 0, 4, 0),    # CUMPLE
    ("0230060397128", "Acumulado", "Automática", 0, 55, 1, 0),   # No cumple
    ("0230060403026", "Acumulado", "Automática", 555, 0, 1, 0),    # No cumple   
]

COLOR_AZUL_SEL = "#0A60C2"
COLOR_BLANCO_TXT = "#FFFFFF"

class SimuladorExpedientes(tk.Tk):
    def __init__(self):
        super().__init__()
        self.title("Expedientes")
        self.geometry("470x330")
        self.resizable(True, True)

        self.filas = [] 
        self.indice_fila_activa = 0

        self.crear_interfaz()
        self.cargar_datos()
        self.resaltar_fila(0)
        self.configurar_atajos_teclado()

    def crear_interfaz(self):
        main_frame = tk.Frame(self)
        main_frame.pack(fill=tk.BOTH, expand=True, padx=4, pady=4)

        # Canvas y barras de desplazamiento
        self.canvas = tk.Canvas(main_frame, bg="white", borderwidth=1, relief="sunken")
        self.v_scroll = ttk.Scrollbar(main_frame, orient="vertical", command=self.canvas.yview)
        self.h_scroll = ttk.Scrollbar(main_frame, orient="horizontal", command=self.canvas.xview)

        self.canvas.configure(xscrollcommand=self.h_scroll.set, yscrollcommand=self.v_scroll.set)

        self.canvas.grid(row=0, column=0, sticky="nsew")
        self.v_scroll.grid(row=0, column=1, sticky="ns")
        self.h_scroll.grid(row=1, column=0, sticky="ew")

        main_frame.grid_rowconfigure(0, weight=1)
        main_frame.grid_columnconfigure(0, weight=1)

        self.table_frame = tk.Frame(self.canvas, bg="white")
        self.canvas.create_window((0, 0), window=self.table_frame, anchor="nw")

        self.table_frame.bind("<Configure>", lambda e: self.canvas.configure(scrollregion=self.canvas.bbox("all")))

        # Encabezados
        encabezados = [
            "", "Expedientes", "Tipo", "Origen", 
            "Saldo_exigible", "Saldo_costos", "Numero_valores", "Numero_embargos"
        ]
        for col, titulo in enumerate(encabezados):
            lbl = tk.Label(
                self.table_frame,
                text=titulo,
                relief="solid",
                bd=1,
                bg="#ECE9D8",
                padx=6,
                pady=2,
                font=("Tahoma", 8, "bold")
            )
            lbl.grid(row=0, column=col, sticky="nsew")

        # Botones inferiores
        btn_frame = tk.Frame(self)
        btn_frame.pack(fill=tk.X, padx=5, pady=5)

        btn_auto = ttk.Button(btn_frame, text="Evaluar y Enmarcar Patrón", command=self.enmarcar_cumplen_condicion)
        btn_auto.pack(side=tk.LEFT)

        btn_cancelar = ttk.Button(btn_frame, text="Cancelar", command=self.destroy)
        btn_cancelar.pack(side=tk.RIGHT, padx=2)

        btn_aceptar = ttk.Button(btn_frame, text="Aceptar", command=self.obtener_seleccionados)
        btn_aceptar.pack(side=tk.RIGHT, padx=2)

    def cargar_datos(self):
        for idx, row in enumerate(DATOS_SIMULADOS):
            grid_row = idx + 1
            check_var = tk.BooleanVar(value=False)
            
            # Checkbox
            chk = tk.Checkbutton(
                self.table_frame,
                variable=check_var,
                bg="white",
                activebackground="white",
                takefocus=0,
                relief="solid",
                bd=1
            )
            chk.grid(row=grid_row, column=0, padx=2, pady=1)

            labels_fila = []
            for col_idx, valor in enumerate(row, start=1):
                # Alinear a la izquierda solo las columnas Numero_valores (col_idx==6)
                # y Numero_embargos (col_idx==7). El resto a la derecha.
                anchor = "w" if col_idx in (6, 7) else "e"
                lbl = tk.Label(
                    self.table_frame,
                    text=str(valor),
                    bg="white",
                    fg="black",
                    anchor=anchor,
                    font=("Tahoma", 8),
                    padx=6,
                    pady=2,
                    relief="solid",
                    bd=1
                )
                lbl.grid(row=grid_row, column=col_idx, sticky="nsew")
                lbl.bind("<Button-1>", lambda event, i=idx: self.resaltar_fila(i))
                labels_fila.append(lbl)

            self.filas.append({
                "var": check_var,
                "chk": chk,
                "labels": labels_fila,
                "datos": row
            })

    def configurar_atajos_teclado(self):
        """Asocia las teclas de navegación y acción."""
        self.bind_all("<Up>", self.mover_arriba)
        self.bind_all("<Down>", self.mover_abajo)
        self.bind_all("<Left>", lambda e: self.canvas.xview_scroll(-2, "units") or "break")
        self.bind_all("<Right>", lambda e: self.canvas.xview_scroll(2, "units") or "break")
        self.bind_all("<space>", self.alternar_checkbox_actual)

    def mover_arriba(self, event=None):
        if self.indice_fila_activa > 0:
            self.resaltar_fila(self.indice_fila_activa - 1)
            self.asegurar_visibilidad_vertical(self.indice_fila_activa)
        return "break"

    def mover_abajo(self, event=None):
        if self.indice_fila_activa < len(self.filas) - 1:
            self.resaltar_fila(self.indice_fila_activa + 1)
            self.asegurar_visibilidad_vertical(self.indice_fila_activa)
        return "break"

    def alternar_checkbox_actual(self, event=None):
        """Alterna el checkbox de la fila activa sin bloquear el siguiente uso del espacio."""
        if 0 <= self.indice_fila_activa < len(self.filas):
            var = self.filas[self.indice_fila_activa]["var"]
            var.set(not var.get())
            self.focus_set()
            return "break"
        return None

    def asegurar_visibilidad_vertical(self, idx):
        """Ajusta el scroll vertical para que la fila activa no quede oculta."""
        total_filas = len(self.filas)
        posicion_relativa = idx / total_filas
        
        y1, y2 = self.canvas.yview()
        if posicion_relativa < y1:
            self.canvas.yview_moveto(posicion_relativa)
        elif posicion_relativa > (y2 - 0.15):
            self.canvas.yview_moveto(min(1.0, posicion_relativa - 0.25))

    def resaltar_fila(self, nuevo_idx):
        if not self.filas:
            return

        if self.indice_fila_activa is not None and self.indice_fila_activa < len(self.filas):
            prev = self.filas[self.indice_fila_activa]
            prev["chk"].configure(bg="white", activebackground="white")
            for lbl in prev["labels"]:
                lbl.configure(bg="white", fg="black")

        self.indice_fila_activa = nuevo_idx
        actual = self.filas[nuevo_idx]
        actual["chk"].configure(bg=COLOR_AZUL_SEL, activebackground=COLOR_AZUL_SEL)
        for lbl in actual["labels"]:
            lbl.configure(bg=COLOR_AZUL_SEL, fg=COLOR_BLANCO_TXT)

        self.focus_set()

    def enmarcar_cumplen_condicion(self):
        for item in self.filas:
            saldo_exigible = item["datos"][3]
            saldo_costas = item["datos"][4]
            num_embargos = item["datos"][6]

            if saldo_exigible == 0 and saldo_costas == 0 and num_embargos == 0:
                item["var"].set(True)
            else:
                item["var"].set(False)

    def obtener_seleccionados(self):
        seleccionados = [item["datos"][0] for item in self.filas if item["var"].get()]
        print(f"Expedientes seleccionados ({len(seleccionados)}): {seleccionados}")

if __name__ == "__main__":
    app = SimuladorExpedientes()
    app.mainloop()