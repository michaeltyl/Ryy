"""
coords_cache.py - Sistema de caché de coordenadas para navegación en RSIRAT
Maneja almacenamiento y recuperación de coordenadas por dependencia
"""

import json
import sys
from pathlib import Path
from datetime import datetime
from typing import Optional, Dict


class CoordsCache:
    """
    Almacena y gestiona coordenadas de elementos UI por dependencia.
    Estructura: cache[dependencia][elemento_name] = {"x": int, "y": int, ...}
    """
    
    def __init__(self, cache_path: Optional[Path] = None):
        """
        Args:
            cache_path: Ruta donde guardar/cargar el JSON de caché (opcional)
                       Si es None, se determinará automáticamente:
                       - En PyInstaller: se guarda en RESULTS_DIR pasado por main.py
                       - En script: se guarda en directorio del script
        """
        self.cache_path = cache_path
        self.cache = {}
        # Cargar solo si cache_path fue establecido explícitamente
        if self.cache_path:
            self.load_from_json()
    
    def get(self, element_name: str, dependencia: str) -> Optional[Dict]:
        """
        Obtiene coordenadas del caché.
        Fuente única de verdad: DISK (JSON)
        
        Estrategia:
        1. Busca en MEMORIA primero (para no releer JSON constantemente)
        2. Si no está, carga del JSON y busca
        3. Si existe en JSON, devuelve y mantiene en memoria para futuro
        
        Args:
            element_name: nombre del elemento (ej: "cobranza_coactiva")
            dependencia: código de dependencia (ej: "21", "23")
        
        Returns:
            Dict con {"x": int, "y": int, ...} o None si no existe
        """
        try:
            dep_key = f"dep_{dependencia}"
            
            # Intento 1: Buscar en memoria
            if dep_key in self.cache and element_name in self.cache[dep_key]:
                return self.cache[dep_key][element_name]
            
            # Intento 2: Cargar del JSON y buscar
            if self.cache_path:
                self.load_from_json()  # Recargar desde DISK
                if dep_key in self.cache and element_name in self.cache[dep_key]:
                    return self.cache[dep_key][element_name]
        
        except Exception:
            pass
        
        return None
    
    def set(self, element_name: str, dependencia: str, x: int, y: int, manual_mode: bool = False) -> None:
        """
        Guarda coordenadas en el caché CON AUTOGUARDADO EN DISK.
        Fuente única de verdad: DISK (JSON)
        
        Flujo:
        1. Actualiza en MEMORIA
        2. Guarda INMEDIATAMENTE en DISK (JSON)
        3. Próximas ejecuciones cargarán del JSON
        
        Args:
            element_name: nombre del elemento
            dependencia: código de dependencia
            x: coordenada X
            y: coordenada Y
            manual_mode: bool indicando si fue capturado por modo manual (default False)
        """
        dep_key = f"dep_{dependencia}"
        
        if dep_key not in self.cache:
            self.cache[dep_key] = {}
        
        self.cache[dep_key][element_name] = {
            "x": x,
            "y": y,
            "timestamp": datetime.now().isoformat(),
            "success_count": 1,
            "manual_mode": manual_mode,  # Registrar si fue capturado por modo manual
            "capture_method": "manual" if manual_mode else "automatic"
        }
        
        # AUTOGUARDADO INMEDIATO EN DISK (fuente única de verdad)
        if self.cache_path:
            try:
                self.save_to_json(self.cache_path)
            except Exception as e:
                print(f"[CACHÉ] Error autoguardando coords: {e}")
    
    def increment_success(self, element_name: str, dependencia: str) -> None:
        """
        Incrementa contador de usos exitosos Y GUARDA EN DISK.
        Mantiene DISK como fuente única de verdad.
        """
        dep_key = f"dep_{dependencia}"
        if dep_key in self.cache and element_name in self.cache[dep_key]:
            self.cache[dep_key][element_name]["success_count"] = \
                self.cache[dep_key][element_name].get("success_count", 0) + 1
            
            # AUTOGUARDADO EN DISK (fuente única de verdad)
            if self.cache_path:
                try:
                    self.save_to_json(self.cache_path)
                except Exception as e:
                    print(f"[CACHÉ] Error autoguardando success_count: {e}")
    
    def clear_by_dependencia(self, dependencia: str) -> None:
        """
        Limpia todas las coordenadas de una dependencia Y GUARDA EN DISK.
        Mantiene DISK actualizado.
        """
        dep_key = f"dep_{dependencia}"
        if dep_key in self.cache:
            del self.cache[dep_key]
        
        # AUTOGUARDADO EN DISK
        if self.cache_path:
            try:
                self.save_to_json(self.cache_path)
            except Exception as e:
                print(f"[CACHÉ] Error autoguardando al limpiar dependencia: {e}")
    
    def clear_all(self) -> None:
        """
        Limpia todo el caché Y GUARDA EN DISK.
        Mantiene DISK actualizado.
        """
        self.cache = {}
        
        # AUTOGUARDADO EN DISK
        if self.cache_path:
            try:
                self.save_to_json(self.cache_path)
            except Exception as e:
                print(f"[CACHÉ] Error autoguardando al limpiar todo: {e}")
    
    def save_to_json(self, path: Path) -> None:
        """
        Guarda caché a archivo JSON.
        FUENTE ÚNICA DE VERDAD - Se llama automáticamente desde set(), 
        increment_success(), clear_*()
        
        Args:
            path: Ruta de destino (se crea el directorio si es necesario)
        """
        try:
            # Validar que la ruta sea accesible (especialmente importante en PyInstaller)
            path = Path(path)  # Convertir a Path si viene como string
            
            # Crear directorio si no existe
            path.parent.mkdir(parents=True, exist_ok=True)
            
            # Guardar JSON con escritura atómica (evitar corrupción)
            # 1. Escribir a archivo temporal
            temp_path = Path(str(path) + ".tmp")
            with open(temp_path, 'w', encoding='utf-8') as f:
                json.dump(self.cache, f, indent=2, default=str)
            
            # 2. Reemplazar el archivo original si temp fue exitoso
            temp_path.replace(path)
            
        except Exception as e:
            print(f"[CACHÉ] Error guardando JSON en {path}: {e}")
    
    def load_from_json(self) -> None:
        """
        Carga caché desde archivo JSON (FUENTE ÚNICA DE VERDAD).
        Se llama:
        1. En __init__() al inicializar
        2. En get() si el elemento no está en memoria
        3. Manualmente si se necesita recargar
        """
        try:
            if self.cache_path:
                cache_path = Path(self.cache_path)
                if cache_path.exists():
                    with open(cache_path, 'r', encoding='utf-8') as f:
                        loaded_cache = json.load(f)
                        # Fusionar con lo que ya hay en memoria (para no perder datos)
                        self.cache.update(loaded_cache)
                        print(f"[CACHÉ] Cargados datos desde: {cache_path}")
                # Si no existe, es normal en primera ejecución
        except json.JSONDecodeError as e:
            print(f"[CACHÉ] JSON corrupto en {self.cache_path}: {e}")
            print(f"[CACHÉ] Comenzando con caché vacío")
            self.cache = {}
        except Exception as e:
            print(f"[CACHÉ] Error cargando desde {self.cache_path}: {e}")
