"""
Script para usar los XPaths capturados y automatizar tareas en SUNARP
Complemento de capturador_xpath.py
"""

from selenium import webdriver
from selenium.webdriver.common.by import By
from selenium.webdriver.support.ui import WebDriverWait
from selenium.webdriver.support import expected_conditions as EC
from selenium.webdriver.chrome.service import Service
import json
import time
import os


class AutomatizadorSUNARP:
    def __init__(self, archivo_xpaths="clics_capturados.txt", url="https://sunarp.gob.pe"):
        """
        Inicializa el automatizador
        
        Args:
            archivo_xpaths: Archivo donde están los XPaths capturados
            url: URL de SUNARP donde se ejecutará la automatización
        """
        self.archivo_xpaths = archivo_xpaths
        self.url = url
        self.driver = None
        self.xpaths = []
        self.wait = None
        
    def cargar_xpaths(self):
        """Carga los XPaths desde el archivo capturado"""
        try:
            with open(self.archivo_xpaths, 'r', encoding='utf-8') as f:
                contenido = f.read()
            
            # Extraer solo los XPaths de la sección "LISTA DE XPATHS"
            inicio = contenido.find("LISTA DE XPATHS (PARA AUTOMATIZACIÓN):")
            if inicio != -1:
                seccion = contenido[inicio:contenido.find("FORMATO JSON")]
                lineas = seccion.split('\n')[2:]  # Saltar encabezados
                
                for linea in lineas:
                    if linea.strip() and linea[0].isdigit():
                        # Extraer XPath (después del número y punto)
                        xpath = linea.split('. ', 1)[1].strip() if '. ' in linea else ""
                        if xpath:
                            self.xpaths.append(xpath)
            
            print(f"✓ Se cargaron {len(self.xpaths)} XPaths")
            return True
            
        except Exception as e:
            print(f"✗ Error al cargar XPaths: {e}")
            return False
    
    def iniciar_navegador(self):
        """Inicia el navegador Chrome"""
        try:
            # Buscar chromedriver.exe localmente
            rutas_posibles = [
                'chromedriver.exe',
                os.path.join(os.path.dirname(__file__), 'chromedriver.exe'),
                os.path.join(os.path.dirname(__file__), 'drivers', 'chromedriver.exe'),
            ]
            
            chromedriver_path = None
            for ruta in rutas_posibles:
                if os.path.exists(ruta):
                    chromedriver_path = ruta
                    print(f"✓ ChromeDriver encontrado en: {ruta}")
                    break
            
            if not chromedriver_path:
                print(f"✗ ChromeDriver no encontrado")
                print(f"   Descarga desde: https://chromedriver.chromium.org/")
                return False
            
            opciones = webdriver.ChromeOptions()
            opciones.add_argument('--no-sandbox')
            opciones.add_argument('--disable-dev-shm-usage')
            
            servicio = Service(chromedriver_path)
            self.driver = webdriver.Chrome(service=servicio, options=opciones)
            self.wait = WebDriverWait(self.driver, 10)
            
            print(f"✓ Navegador abierto")
            self.driver.get(self.url)
            print(f"✓ Navegando a: {self.url}")
            time.sleep(2)
            
            return True
            
        except Exception as e:
            print(f"✗ Error al iniciar navegador: {e}")
            return False
    
    def ejecutar_secuencia_clics(self, indices=None):
        """
        Ejecuta una secuencia de clics basada en los XPaths capturados
        
        Args:
            indices: Lista de índices de clics a ejecutar (None = todos)
        """
        if not indices:
            indices = range(len(self.xpaths))
        
        print(f"\n🤖 Ejecutando {len(indices)} clics...\n")
        
        for idx in indices:
            if idx >= len(self.xpaths):
                print(f"⚠ Índice {idx} fuera de rango")
                continue
            
            xpath = self.xpaths[idx]
            try:
                # Esperar a que el elemento sea visible
                elemento = self.wait.until(
                    EC.element_to_be_clickable((By.XPATH, xpath))
                )
                
                # Hacer clic
                elemento.click()
                print(f"✓ Clic {idx + 1}: Ejecutado correctamente")
                time.sleep(1)  # Esperar entre clics
                
            except Exception as e:
                print(f"✗ Clic {idx + 1}: Error - {e}")
                time.sleep(1)
    
    def llenar_formulario(self, datos_dict):
        """
        Llena un formulario con los datos proporcionados
        
        Args:
            datos_dict: Diccionario con {xpath_input: valor}
        """
        print(f"\n📝 Rellenando {len(datos_dict)} campos...\n")
        
        for i, (xpath, valor) in enumerate(datos_dict.items(), 1):
            try:
                campo = self.wait.until(
                    EC.presence_of_element_located((By.XPATH, xpath))
                )
                
                # Limpiar el campo primero
                campo.clear()
                
                # Escribir el valor
                campo.send_keys(str(valor))
                print(f"✓ Campo {i}: '{valor}' ingresado")
                time.sleep(0.5)
                
            except Exception as e:
                print(f"✗ Campo {i}: Error - {e}")
    
    def captura_pantalla(self, nombre_archivo="captura.png"):
        """Toma una captura de pantalla"""
        try:
            self.driver.save_screenshot(nombre_archivo)
            print(f"✓ Captura guardada: {nombre_archivo}")
        except Exception as e:
            print(f"✗ Error al capturar pantalla: {e}")
    
    def extraer_datos(self, xpath_elementos):
        """
        Extrae datos de elementos específicos
        
        Args:
            xpath_elementos: Lista de XPaths de elementos a extraer
            
        Returns:
            Lista con los datos extraídos
        """
        datos = []
        
        for xpath in xpath_elementos:
            try:
                elemento = self.driver.find_element(By.XPATH, xpath)
                texto = elemento.text
                datos.append(texto)
                print(f"✓ Datos extraídos: {texto[:50]}")
            except Exception as e:
                print(f"✗ Error extrayendo datos: {e}")
                datos.append("")
        
        return datos
    
    def esperar_elemento(self, xpath, segundos=10):
        """Espera a que un elemento esté visible"""
        try:
            elemento = WebDriverWait(self.driver, segundos).until(
                EC.visibility_of_element_located((By.XPATH, xpath))
            )
            print(f"✓ Elemento encontrado")
            return elemento
        except Exception as e:
            print(f"✗ Elemento no encontrado: {e}")
            return None
    
    def cerrar(self):
        """Cierra el navegador"""
        if self.driver:
            self.driver.quit()
            print("✓ Navegador cerrado")
    
    def obtener_resumen(self):
        """Muestra un resumen de los XPaths cargados"""
        print("\n" + "="*70)
        print("RESUMEN DE XPATHS DISPONIBLES")
        print("="*70)
        print(f"Total de XPaths: {len(self.xpaths)}\n")
        
        for i, xpath in enumerate(self.xpaths, 1):
            print(f"{i}. {xpath[:70]}{'...' if len(xpath) > 70 else ''}")


# Ejemplos de uso
def ejemplo_basico():
    """Ejemplo 1: Ejecutar secuencia de clics básica"""
    print("ejemplo_basico\n")
    
    auto = AutomatizadorSUNARP()
    
    if not auto.cargar_xpaths():
        return
    
    auto.obtener_resumen()
    
    if not auto.iniciar_navegador():
        return
    
    # Ejecutar los primeros 3 clics
    auto.ejecutar_secuencia_clics(indices=[0, 1, 2])
    
    time.sleep(5)
    auto.cerrar()


def ejemplo_llenar_formulario():
    """Ejemplo 2: Llenar un formulario"""
    print("\nEjemplo: Llenar formulario\n")
    
    auto = AutomatizadorSUNARP()
    
    if not auto.cargar_xpaths():
        return
    
    if not auto.iniciar_navegador():
        return
    
    # Datos a llenar (necesitas tener XPaths de inputs)
    datos = {
        "//input[@placeholder='Nombre']": "Juan Pérez",
        "//input[@placeholder='DNI']": "12345678",
        "//input[@placeholder='Email']": "juan@example.com"
    }
    
    auto.llenar_formulario(datos)
    
    time.sleep(5)
    auto.cerrar()


def ejemplo_extraer_datos():
    """Ejemplo 3: Extraer datos de la página"""
    print("\nEjemplo: Extraer datos\n")
    
    auto = AutomatizadorSUNARP()
    
    if not auto.iniciar_navegador():
        return
    
    # XPaths de elementos a extraer
    xpaths_extraer = [
        "//h1",
        "//p[@class='descripcion']",
        "//div[@class='resultado']"
    ]
    
    datos = auto.extraer_datos(xpaths_extraer)
    
    print("\nDatos extraídos:")
    for i, dato in enumerate(datos, 1):
        print(f"  {i}. {dato}")
    
    time.sleep(5)
    auto.cerrar()


def main():
    """Menú principal"""
    print("🤖 AUTOMATIZADOR SUNARP\n")
    
    opciones = {
        "1": ("Ejecutar secuencia de clics", ejemplo_basico),
        "2": ("Llenar formulario", ejemplo_llenar_formulario),
        "3": ("Extraer datos", ejemplo_extraer_datos),
    }
    
    print("Opciones disponibles:")
    for key, (desc, _) in opciones.items():
        print(f"  {key}. {desc}")
    
    opcion = input("\nSelecciona una opción (1-3): ").strip()
    
    if opcion in opciones:
        _, funcion = opciones[opcion]
        funcion()
    else:
        print("❌ Opción no válida")


if __name__ == "__main__":
    # Por defecto, ejecuta el ejemplo básico
    # Descomenta la función que desees usar:
    
    main()
    
    # O ejecuta directamente:
    # ejemplo_basico()
    # ejemplo_llenar_formulario()
    # ejemplo_extraer_datos()
