"""
Script para capturar XPaths de elementos clickeados en una página web
Útil para extraer la información de navegación y poder automatizar luego
"""

from selenium import webdriver
from selenium.webdriver.common.by import By
from selenium.webdriver.support.ui import WebDriverWait
from selenium.webdriver.support import expected_conditions as EC
from selenium.webdriver.chrome.service import Service
from datetime import datetime
import time
import json
import os
import sys

class CapturadorXPath:
    def __init__(self, url_inicial, archivo_salida="clics_capturados.txt"):
        """
        Inicializa el capturador de XPaths
        
        Args:
            url_inicial: URL de inicio (ej: https://sunarp.gob.pe)
            archivo_salida: Nombre del archivo donde se guardarán los clics
        """
        self.url_inicial = url_inicial
        self.archivo_salida = archivo_salida
        self.clics_capturados = []
        self.driver = None
        self.contador_clics = 0
        
    def iniciar_navegador(self):
        """Inicia el navegador Chrome con opciones necesarias"""
        try:
            # Buscar chromedriver.exe localmente
            rutas_posibles = [
                'chromedriver.exe',
                os.path.join(os.path.dirname(__file__), 'chromedriver.exe'),
                os.path.join(os.path.dirname(__file__), 'drivers', 'chromedriver.exe'),
            ]
            
            chromedriver_path = None
            for ruta in rutas_posibles:
                if os.path.exists(ruta):
                    chromedriver_path = ruta
                    print(f"✓ ChromeDriver encontrado en: {ruta}")
                    break
            
            if not chromedriver_path:
                print(f"✗ ChromeDriver no encontrado")
                print(f"   Lugares buscados:")
                for ruta in rutas_posibles:
                    print(f"     - {os.path.abspath(ruta)}")
                print(f"\n   Descarga chromedriver.exe desde: https://chromedriver.chromium.org/")
                return False
            
            opciones = webdriver.ChromeOptions()
            # opciones.add_argument('--headless')  # Descomenta para modo headless
            opciones.add_argument('--no-sandbox')
            opciones.add_argument('--disable-dev-shm-usage')
            
            servicio = Service(chromedriver_path)
            self.driver = webdriver.Chrome(service=servicio, options=opciones)
            print(f"✓ Navegador abierto")
            
            # Navegar a la URL inicial
            self.driver.get(self.url_inicial)
            print(f"✓ Navegando a: {self.url_inicial}")
            time.sleep(2)
            
        except Exception as e:
            print(f"✗ Error al iniciar navegador: {e}")
            return False
        
        return True
    
    def inyectar_capturador_javascript(self):
        """Inyecta JavaScript para capturar clics y registrar XPaths"""
        script = """
        window.clicsCapturados = [];
        
        // Función para obtener el XPath de un elemento
        function obtenerXPath(elemento) {
            if (elemento.id !== '')
                return "//*[@id='" + elemento.id + "']";
            if (elemento === document.body)
                return "/body";
            
            var nombres = [];
            var actual = elemento;
            while (actual && actual.tagName !== 'HTML') {
                var index = 1;
                var hermano = actual.previousSibling;
                while (hermano) {
                    if (hermano.nodeType === 1 && hermano.tagName === actual.tagName) {
                        index++;
                    }
                    hermano = hermano.previousSibling;
                }
                nombres.unshift(actual.tagName.toLowerCase() + '[' + index + ']');
                actual = actual.parentNode;
            }
            nombres.unshift('html[1]');
            return '/' + nombres.join('/');
        }
        
        // Capturador de eventos
        document.addEventListener('click', function(evento) {
            var elemento = evento.target;
            var xpath = obtenerXPath(elemento);
            var info = {
                numero: window.clicsCapturados.length + 1,
                timestamp: new Date().toLocaleTimeString(),
                elemento: elemento.tagName,
                xpath: xpath,
                texto: elemento.innerText ? elemento.innerText.substring(0, 100) : '',
                id: elemento.id || '',
                clase: elemento.className || ''
            };
            window.clicsCapturados.push(info);
            console.log('Clic capturado [' + info.numero + ']: ' + xpath);
        }, true);
        
        console.log('✓ Capturador de XPaths activado');
        """
        
        try:
            self.driver.execute_script(script)
            print("✓ Capturador JavaScript inyectado correctamente")
            return True
        except Exception as e:
            print(f"✗ Error al inyectar JavaScript: {e}")
            return False
    
    def mostrar_instrucciones(self):
        """Muestra las instrucciones al usuario"""
        print("\n" + "="*70)
        print("CAPTURADOR DE XPATHS - INSTRUCCIONES")
        print("="*70)
        print("\n📝 Ahora puedes:")
        print("  1. Hacer clic en los elementos de la web que desees automatizar")
        print("  2. Cada clic será registrado con su XPath")
        print("  3. Cuando termines, presiona Enter en la consola")
        print("\n💡 Nota: Los clics se guardarán automáticamente en:", self.archivo_salida)
        print("\n" + "="*70 + "\n")
    
    def capturar_clics(self, tiempo_espera=300):
        """
        Captura los clics durante el tiempo especificado (en segundos)
        
        Args:
            tiempo_espera: Tiempo máximo de espera en segundos (default 5 minutos)
        """
        self.mostrar_instrucciones()
        
        try:
            tiempo_inicio = time.time()
            while True:
                time.sleep(1)
                
                # Obtener clics capturados
                clics_actuales = self.driver.execute_script(
                    "return window.clicsCapturados || []"
                )
                
                nuevo_contador = len(clics_actuales)
                if nuevo_contador > self.contador_clics:
                    # Hubo nuevos clics
                    for clic in clics_actuales[self.contador_clics:]:
                        print(f"  [{clic['numero']}] {clic['elemento'].upper()} - {clic['xpath']}")
                    self.contador_clics = nuevo_contador
                
                # Verificar si pasó el tiempo máximo
                tiempo_transcurrido = time.time() - tiempo_inicio
                if tiempo_transcurrido > tiempo_espera:
                    print(f"\n⚠ Tiempo máximo alcanzado ({tiempo_espera}s)")
                    break
                
                # Permitir que el usuario presione Enter para salir
                print(f"  (Capturados: {self.contador_clics} clics - Presiona Ctrl+C para salir)")
                
        except KeyboardInterrupt:
            print("\n✓ Captura detenida por el usuario")
        
        # Obtener los clics finales
        self.clics_capturados = self.driver.execute_script(
            "return window.clicsCapturados || []"
        )
    
    def guardar_resultados(self):
        """Guarda los XPaths capturados en un archivo de texto"""
        if not self.clics_capturados:
            print("✗ No hay clics para guardar")
            return False
        
        try:
            with open(self.archivo_salida, 'w', encoding='utf-8') as f:
                f.write("="*80 + "\n")
                f.write(f"CAPTURA DE XPATHS - {datetime.now().strftime('%d/%m/%Y %H:%M:%S')}\n")
                f.write("="*80 + "\n\n")
                
                f.write(f"Total de clics capturados: {len(self.clics_capturados)}\n\n")
                
                # Formato detallado
                f.write("-"*80 + "\n")
                f.write("DETALLE DE CADA CLIC:\n")
                f.write("-"*80 + "\n\n")
                
                for i, clic in enumerate(self.clics_capturados, 1):
                    f.write(f"[{i}] CLIC #{clic['numero']}\n")
                    f.write(f"    Hora: {clic['timestamp']}\n")
                    f.write(f"    Elemento: {clic['elemento']}\n")
                    f.write(f"    XPath: {clic['xpath']}\n")
                    f.write(f"    Texto: {clic['texto']}\n")
                    f.write(f"    ID: {clic['id']}\n")
                    f.write(f"    Clase: {clic['clase']}\n")
                    f.write("\n")
                
                # Formato de lista simple (solo XPaths)
                f.write("\n" + "-"*80 + "\n")
                f.write("LISTA DE XPATHS (PARA AUTOMATIZACIÓN):\n")
                f.write("-"*80 + "\n\n")
                
                for i, clic in enumerate(self.clics_capturados, 1):
                    f.write(f"{i}. {clic['xpath']}\n")
                
                # Formato JSON
                f.write("\n" + "-"*80 + "\n")
                f.write("FORMATO JSON (PARA INTEGRACIÓN):\n")
                f.write("-"*80 + "\n\n")
                f.write(json.dumps(self.clics_capturados, ensure_ascii=False, indent=2))
            
            print(f"\n✓ Resultados guardados en: {self.archivo_salida}")
            return True
            
        except Exception as e:
            print(f"✗ Error al guardar resultados: {e}")
            return False
    
    def mostrar_resumen(self):
        """Muestra un resumen de los clics capturados"""
        print("\n" + "="*70)
        print("RESUMEN DE CAPTURA")
        print("="*70)
        print(f"Total de clics: {len(self.clics_capturados)}")
        
        if self.clics_capturados:
            print("\nClics capturados:")
            for i, clic in enumerate(self.clics_capturados, 1):
                print(f"  {i}. [{clic['elemento']}] {clic['texto'][:50] if clic['texto'] else '(sin texto)'}")
    
    def cerrar(self):
        """Cierra el navegador"""
        if self.driver:
            self.driver.quit()
            print("✓ Navegador cerrado")
    
    def ejecutar(self):
        """Ejecuta el proceso completo de captura"""
        print("🤖 Iniciando Capturador de XPaths...\n")
        
        # Iniciar navegador
        if not self.iniciar_navegador():
            return
        
        # Inyectar capturador
        if not self.inyectar_capturador_javascript():
            self.cerrar()
            return
        
        # Capturar clics
        self.capturar_clics()
        
        # Mostrar resumen
        self.mostrar_resumen()
        
        # Guardar resultados
        self.guardar_resultados()
        
        # Cerrar
        self.cerrar()
        
        print("\n✓ Proceso completado")


def main():
    """Función principal"""
    print("🌐 CONFIGURACIÓN INICIAL\n")
    
    # Solicitar URL
    url = input("Ingresa la URL de SUNARP (ej: https://sunarp.gob.pe): ").strip()
    if not url:
        url = "https://sunarp.gob.pe"
    
    # Solicitar nombre del archivo
    archivo = input("Nombre del archivo de salida (default: clics_capturados.txt): ").strip()
    if not archivo:
        archivo = "clics_capturados.txt"
    
    # Crear y ejecutar capturador
    capturador = CapturadorXPath(url, archivo)
    
    try:
        capturador.ejecutar()
    except Exception as e:
        print(f"\n✗ Error durante la ejecución: {e}")
        capturador.cerrar()


if __name__ == "__main__":
    main()
