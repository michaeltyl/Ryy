"""
test_descendientes.py - Script de PRUEBA para detectar estructura de ventanas
Objetivo: Identificar dónde está realmente el mensaje de aviso y sus descendientes

FLUJO:
1. Abre RSIRAT
2. Completa login (dependencia + contraseña)
3. Detecta automáticamente el mensaje de aviso
4. Imprime estructura de ventanas y descendientes
5. Da ENTER automáticamente para cerrar
"""

import time
import os
import sys
import logging
from pathlib import Path
import pyautogui
import keyboard
from pywinauto import Desktop, Application

# Configurar logging
logging.basicConfig(
    level=logging.INFO,
    format='%(asctime)s - %(levelname)s - %(message)s'
)
logger = logging.getLogger(__name__)

SCRIPT_DIR = Path(__file__).parent
SHORTCUT_PATH = SCRIPT_DIR / "Actualiza RSIRAT.lnk"
PASSWORD_FILE = SCRIPT_DIR / "contrasena.txt"
DEPENDENCIA_FILE = SCRIPT_DIR / "dependencia.txt"

# ===========================
# PASO 1: ABRIR RSIRAT
# ===========================
def abrir_rsirat():
    """Abre RSIRAT usando el shortcut."""
    logger.info("Abriendo Actualiza RSIRAT.lnk...")
    if not SHORTCUT_PATH.exists():
        logger.error(f"No existe: {SHORTCUT_PATH}")
        return False
    
    try:
        os.startfile(str(SHORTCUT_PATH))
        logger.info("Esperando 15 segundos para que RSIRAT cargue...")
        time.sleep(15)
        return True
    except Exception as e:
        logger.error(f"Error abriendo RSIRAT: {e}")
        return False

# ===========================
# PASO 2: COMPLETAR LOGIN
# ===========================
def completar_login():
    """Completa login con dependencia y contraseña."""
    logger.info("Completando login...")
    
    # Leer dependencia
    if not DEPENDENCIA_FILE.exists():
        logger.error(f"No existe: {DEPENDENCIA_FILE}")
        return False
    
    with open(DEPENDENCIA_FILE, 'r', encoding='utf-8') as f:
        dependencia = f.read().strip()
    
    # Leer contraseña
    if not PASSWORD_FILE.exists():
        logger.error(f"No existe: {PASSWORD_FILE}")
        return False
    
    with open(PASSWORD_FILE, 'r', encoding='utf-8') as f:
        password = f.read().strip()
    
    try:
        # Buscar campos de login
        logger.info("Buscando campos de login...")
        time.sleep(2)
        
        # Escribir dependencia
        logger.info(f"Escribiendo dependencia: {dependencia}")
        pyautogui.write(dependencia, interval=0.02)
        time.sleep(0.5)
        pyautogui.press('tab')
        time.sleep(0.5)
        
        # Escribir contraseña
        logger.info("Escribiendo contraseña...")
        pyautogui.write(password, interval=0.02)
        time.sleep(0.5)
        
        # Click en Aceptar
        logger.info("Presionando Enter para aceptar...")
        pyautogui.press('return')
        time.sleep(5)
        
        return True
    except Exception as e:
        logger.error(f"Error en login: {e}")
        return False

# ===========================
# PASO 3: DETECTAR MENSAJE Y ANALIZAR
# ===========================
def detectar_y_analizar_mensaje():
    """Detecta el mensaje de aviso y analiza su estructura."""
    logger.info("\n" + "="*80)
    logger.info("ESPERANDO MENSAJE DE AVISO...")
    logger.info("="*80)
    
    max_intentos = 30  # 30 segundos esperando
    intento = 0
    
    while intento < max_intentos:
        try:
            desktop = Desktop(backend='uia')
            ventanas = desktop.windows()
            
            logger.info(f"\n[INTENTO {intento+1}/{max_intentos}] Buscando ventanas...")
            logger.info(f"Total de ventanas: {len(ventanas)}")
            
            # Listar todas las ventanas
            for i, ventana in enumerate(ventanas):
                try:
                    nombre = ventana.window_text() or "(sin nombre)"
                    logger.info(f"  [{i}] {nombre[:60]}")
                except:
                    pass
            
            # Buscar mensaje de aviso
            mensaje_encontrado = False
            for ventana in ventanas:
                try:
                    descendants = ventana.descendants()
                    
                    for desc in descendants:
                        try:
                            texto = desc.window_text()
                            if "APLICATIVO nO PUEDE SER accedido" in texto or "Estimado Usuario" in texto:
                                logger.info("\n" + "="*80)
                                logger.info("✓ MENSAJE DE AVISO ENCONTRADO")
                                logger.info("="*80)
                                
                                # Analizar mensaje
                                analizar_elemento(desc)
                                
                                mensaje_encontrado = True
                                return True
                        except:
                            pass
                except:
                    pass
            
            if not mensaje_encontrado:
                intento += 1
                time.sleep(1)
            else:
                break
        
        except Exception as e:
            logger.error(f"Error iterando ventanas: {e}")
            intento += 1
            time.sleep(1)
    
    logger.warning("No se detectó mensaje de aviso en 30 segundos")
    return False

# ===========================
# PASO 4: ANALIZAR ESTRUCTURA
# ===========================
def analizar_elemento(elemento):
    """Analiza en detalle un elemento y su estructura."""
    try:
        logger.info("\n--- INFORMACIÓN DEL ELEMENTO ---")
        
        # Nombre/tipo de elemento
        try:
            logger.info(f"Element type: {elemento.element_type}")
        except:
            pass
        
        # Contenido
        try:
            texto = elemento.window_text()
            logger.info(f"Contenido:\n{texto}")
        except:
            pass
        
        # Ancestros (ventanas padres)
        logger.info("\n--- ANCESTROS (VENTANAS PADRES) ---")
        try:
            # Intentar obtener ancestros
            padre = None
            try:
                padre = elemento.parent()
            except:
                padre = None
            
            nivel = 0
            while padre and nivel < 10:
                try:
                    nombre = padre.window_text() or "(sin nombre)"
                    tipo = str(padre.element_type) if hasattr(padre, 'element_type') else "?"
                    logger.info(f"  [Nivel {nivel}] Tipo: {tipo}, Nombre: {nombre[:60]}")
                    
                    # Intentar siguiente padre
                    try:
                        padre = padre.parent()
                    except:
                        padre = None
                    nivel += 1
                except:
                    break
        except Exception as e:
            logger.error(f"Error leyendo ancestros: {e}")
        
        # Hermanos (elementos al mismo nivel)
        logger.info("\n--- HERMANOS (ELEMENTOS AL MISMO NIVEL) ---")
        try:
            padre = elemento.parent()
            if padre:
                hermanos = padre.children()
                logger.info(f"Total de hermanos: {len(hermanos)}")
                
                for i, hermano in enumerate(hermanos[:10]):  # Máximo 10
                    try:
                        tipo = str(hermano.element_type) if hasattr(hermano, 'element_type') else "?"
                        texto = hermano.window_text() or "(vacío)"
                        logger.info(f"  [{i}] Tipo: {tipo}, Texto: {texto[:50]}")
                    except:
                        pass
        except Exception as e:
            logger.error(f"Error leyendo hermanos: {e}")
        
        # Descendientes (elementos dentro)
        logger.info("\n--- DESCENDIENTES (ELEMENTOS DENTRO) ---")
        try:
            padre = elemento.parent()
            if padre:
                descendants = padre.descendants()
                logger.info(f"Total de descendientes: {len(descendants)}")
                
                # Filtrar solo Text
                textos = []
                for desc in descendants:
                    try:
                        tipo = str(desc.element_type).lower() if hasattr(desc, 'element_type') else ""
                        if "text" in tipo or "static" in tipo:
                            texto = desc.window_text()
                            if texto:
                                textos.append((tipo, texto[:80]))
                    except:
                        pass
                
                logger.info(f"Elementos Text encontrados: {len(textos)}")
                for tipo, texto in textos[:20]:  # Máximo 20
                    logger.info(f"  - {tipo}: {texto}")
        except Exception as e:
            logger.error(f"Error leyendo descendientes: {e}")
        
    except Exception as e:
        logger.error(f"Error analizando elemento: {e}")

# ===========================
# PASO 5: CERRAR MENSAJE
# ===========================
def cerrar_mensaje():
    """Da ENTER para cerrar el mensaje."""
    logger.info("\n" + "="*80)
    logger.info("Presionando ENTER para cerrar mensaje...")
    logger.info("="*80)
    
    time.sleep(1)
    pyautogui.press('return')
    time.sleep(2)
    
    logger.info("Mensaje cerrado")

# ===========================
# PASO 6: CERRAR APLICACIÓN
# ===========================
def cerrar_rsirat():
    """Cierra RSIRAT."""
    logger.info("\nCerrando RSIRAT...")
    try:
        pyautogui.hotkey('alt', 'f4')
        time.sleep(2)
    except:
        pass

# ===========================
# MAIN
# ===========================
def main():
    logger.info("="*80)
    logger.info("INICIANDO PRUEBA DE DESCENDIENTES")
    logger.info("="*80)
    
    try:
        # Paso 1: Abrir RSIRAT
        if not abrir_rsirat():
            logger.error("No se pudo abrir RSIRAT")
            return False
        
        # Paso 2: Completar login
        if not completar_login():
            logger.error("No se pudo completar login")
            return False
        
        # Paso 3: Detectar y analizar mensaje
        if not detectar_y_analizar_mensaje():
            logger.error("No se detectó mensaje")
            return False
        
        # Paso 4: Cerrar mensaje
        cerrar_mensaje()
        
        # Paso 5: Cerrar aplicación
        cerrar_rsirat()
        
        logger.info("\n" + "="*80)
        logger.info("PRUEBA COMPLETADA")
        logger.info("="*80)
        
        return True
    
    except Exception as e:
        logger.error(f"Error general: {e}", exc_info=True)
        return False
    
    finally:
        logger.info("Fin del script")

if __name__ == "__main__":
    success = main()
    sys.exit(0 if success else 1)
