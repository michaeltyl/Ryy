"""
app_driver.py - Controlador de la aplicación RSIRAT
Encapsula:
  1. Apertira/cierre de app (pyautogui + .lnk)
  2. Login (campos, detección de errores contraseña)
  3. Navegación (Cobranza Coactiva, Exp. Cob. Individual)
  4. Entrada de expedientes (inicial, con Accesos)
  5. Accesos → Cambio de Expediente
  6. Trabar Embargo, Intervención, Depósito
  7. Ingreso de INTERVENTOR, PLAZO, MONTO
  8. Detecciones centralizadas de mensajes (MessageCatalog)
  9. Extracción de RC
  10. Cierre de diálogos

Retorna siempre Outcome explícito
"""

import time
import logging
import os
import re
from pathlib import Path
from typing import Optional, Tuple

import pyautogui
from pywinauto import Application, Desktop, findwindows

from logica import Outcome


# CONSTANTES Y SELECTORES
RSIRAT_WINDOW_PATTERNS = [
    "SIRAT"
]
RSIRAT_WAIT_TIMEOUT = 30
UI_WAIT_SMALL = 0.5
UI_WAIT_MEDIUM = 1.0
UI_WAIT_LARGE = 2.0
DETECT_TIMEOUT = 2.0
MSAA_BACKEND = "uia"





# APP DRIVER CLASS
class AppDriver:
    """Controlador de aplicación RSIRAT."""
    
    def __init__(self, logger: logging.Logger, shortcut_path: Path):
        self.logger = logger
        self.shortcut_path = shortcut_path
        self.app = None
        self.main_window = None
        # Variables para almacenar coordenadas reutilizables
        self.trabar_embargo_coords = None
        self.proceso_embargo_coords = None
    
    # APERTURA / CIERRE
    
    def open_app(self) -> bool:
        """Abre RSIRAT usando el acceso directo."""
        try:
            self.logger.info(f"[ACCIÓN] Abriendo {self.shortcut_path.name}...")
            self.logger.info(f"  └─ Ruta: {self.shortcut_path}")
            self.logger.info(f"  └─ Comando: os.startfile()")
            os.startfile(str(self.shortcut_path))
            self.logger.info(f"  └─ Esperando 15 segundos para que la app cargue completamente...")
            time.sleep(15)  # Aumentado de 8 a 15 segundos (app puede demorar con ventana sync)
            self.logger.info(f" Aplicación abierta exitosamente")
            return True
        except Exception as e:

            self.logger.error(f" Error abriendo aplicación: {e}")
            return False
    
    def close_app(self) -> bool:
        """Cierra RSIRAT con Alt+F4."""
        try:
            self.logger.info("[ACCIÓN] Cerrando aplicación...")
            self.logger.info("  └─ Combinación de teclas: ALT+F4")
            pyautogui.hotkey('alt', 'f4')
            self.logger.info("  └─ Esperando 2 segundos...")
            time.sleep(2)
            self.logger.info(" Aplicación cerrada")
            return True
        except Exception as e:
            self.logger.error(f" Error cerrando aplicación: {e}")
            return False
    
    def check_app_window_exists(self) -> bool:
        """
        Verifica si la ventana SIRAT sigue abierta.
        Retorna True si está abierta, False si se cerró (posible crasheo).
        """
        try:
            desktop = Desktop(backend=MSAA_BACKEND)
            
            try:
                windows = desktop.windows()
                for window in windows:
                    try:
                        title = str(window.element_info.name or "")
                        if title == "SIRAT":
                            return True
                    except Exception:
                        continue
            except Exception:
                pass
            
            self.logger.warning("[ALERTA] Ventana SIRAT NO encontrada - Aplicación posiblemente cerrada/crasheada")
            return False
        
        except Exception as e:
            self.logger.error(f"Error verificando ventana SIRAT: {e}")
            return False
    
    # VALIDACIONES PRE-LOGIN
    
    def check_and_disable_capslock(self):
        """
        Detecta si Bloq Mayús (CAPS LOCK) está activado.
        Si está activado, lo desactiva presionando la tecla CAPS LOCK.
        Esto evita que la contraseña se escriba en mayúsculas.
        """
        try:
            import ctypes
            # GetKeyState retorna valor par si la tecla NO está pulsada, impar si está pulsada
            # VK_CAPITAL = 0x14 (código de CAPS LOCK)
            capslock_state = ctypes.windll.user32.GetKeyState(0x14)
            
            # Si capslock_state es impar, Bloq Mayús está activado
            if capslock_state % 2 == 1:
                self.logger.warning(" Bloq Mayús (CAPS LOCK) está ACTIVADO")
                self.logger.info("  Desactivando Bloq Mayús...")
                pyautogui.press('capslock')
                time.sleep(0.5)
                self.logger.info("   Bloq Mayús desactivado")
            else:
                self.logger.info(" Bloq Mayús está desactivado (normal)")
        except Exception as e:
            self.logger.warning(f"No se pudo verificar Bloq Mayús: {e}")
    
    # ENFOQUE DE VENTANA (FUNCIÓN GENERAL)
    
    def ensure_sirat_focus(self):
        """
        FUNCIÓN GENERAL DE ENFOQUE DE VENTANA SIRAT.
        
        Responsabilidades:
        1. Buscar ventana SIRAT mediante múltiples estrategias escalonadas
        2. Traer a frente y establecer foco (set_focus)
        3. Actualizar cache (self.app) para reutilización
        4. Validar que la ventana encontrada es realmente SIRAT
        
        ESTRATEGIAS (en orden):
        1. Verificar cache local (self.app) si existe
        2. Buscar por título exacto "SIRAT"
        3. Fallback a ventana activa con validación
        4. Buscar por patrón (RSIRAT, COBRANZA, etc)
        
        RETORNA: Referencia a ventana SIRAT o None si no se encuentra
        
        BENEFICIOS:
        - Centraliza lógica de búsqueda (eliminadas repeticiones)
        - set_focus() integrado = previene "ventana no encontrada"
        - Cache actualizado = búsquedas más rápidas
        - Validación extra = early error detection
        """
        try:
            # ESTRATEGIA 1: Verificar cache local
            if self.app is not None:
                try:
                    if self.app.exists():
                        self.app.set_focus()
                        self.logger.debug("[ensure_sirat_focus] Cache válido, ventana enfocada")
                        self.logger.info("[ ESTRATEGIA 1 FUNCIONÓ] Cache local válido - ventana enfocada")
                    return self.app
                except Exception:
                    self.app = None  # Invalidar cache si falla
                    self.logger.debug("[ ESTRATEGIA 1 FALLÓ] Cache inválido")
            
            # ESTRATEGIA 2: Buscar por título exacto "SIRAT"
            try:
                desktop = Desktop(backend=MSAA_BACKEND)
                app = desktop.window(title="SIRAT")
                if app and app.exists(timeout=1):
                    app.set_focus()
                    self.app = app  # Actualizar cache
                    self.logger.debug("[ensure_sirat_focus] Ventana SIRAT encontrada por título exacto")
                    self.logger.info("[ ESTRATEGIA 2 FUNCIONÓ] Ventana encontrada por título exacto - enfocada")
                    return app
            except Exception:
                self.logger.debug("[ ESTRATEGIA 2 FALLÓ] No se encontró ventana por título exacto")
                pass
            
            # ESTRATEGIA 3: Fallback a ventana activa con validación
            try:
                desktop = Desktop(backend=MSAA_BACKEND)
                app = desktop.active()
                if app:
                    title = app.window_title().lower()
                    # Validar que sea SIRAT (por título o clase)
                    if "sirat" in title or "rsirat" in title or "cobranza" in title:
                        app.set_focus()
                        self.app = app
                        self.logger.debug(f"[ensure_sirat_focus] Ventana activa validada como SIRAT: '{title}'")
                        self.logger.info(f"[ ESTRATEGIA 3 FUNCIONÓ] Ventana activa validada ('{title}') - enfocada")
                        return app
            except Exception:
                self.logger.debug("[ ESTRATEGIA 3 FALLÓ] No se validó ventana activa como SIRAT")
                pass
            
            # ESTRATEGIA 4: Buscar por patrón usando findwindows
            try:
                for pattern in RSIRAT_WINDOW_PATTERNS:
                    windows = findwindows.find_windows(title_re=f".*{pattern}.*")
                    if windows:
                        app = Application(backend=MSAA_BACKEND).connect(
                            handle=windows[0]
                        ).top_window()
                        app.set_focus()
                        self.app = app
                        self.logger.debug(f"[ensure_sirat_focus] Ventana encontrada por patrón '{pattern}'")
                        self.logger.info(f"[ ESTRATEGIA 4 FUNCIONÓ] Ventana encontrada por patrón ('{pattern}') - enfocada")
                        return app
            except Exception:
                self.logger.debug("[ ESTRATEGIA 4 FALLÓ] No se encontró ventana por patrón")
                pass
            
            # No encontrada con ninguna estrategia
            self.logger.error("[ensure_sirat_focus] No se pudo encontrar/enfocar ventana SIRAT después de 4 intentos")
            self.app = None
            return None
        
        except Exception as e:
            self.logger.error(f"[ensure_sirat_focus] Error general: {e}")
            self.app = None
            return None
    
    def find_sirat_window(self):
        """
        Obtiene referencia a ventana SIRAT usando Desktop y MSAA backend.
        
        Utilizado por funciones de detección de mensajes (detect_*) que necesitan
        buscar elementos SOLO dentro de la ventana SIRAT (optimización).
        
        Retorna: 
            - Ventana SIRAT si se encuentra y existe
            - None si no se encuentra o hay error
        
        IMPORTANTE:
        - Este método es ACCESO DIRECTO a ventana (sin enfocar)
        - Para enfocar, usar ensure_sirat_focus()
        - Para búsquedas optimizadas de mensajes, usar este método
        """
        try:
            desktop = Desktop(backend=MSAA_BACKEND)
            sirat_window = desktop.window(title="SIRAT")
            
            if sirat_window.exists(timeout=1):
                return sirat_window
            
            return None
        
        except Exception as e:
            self.logger.debug(f"find_sirat_window() error: {e}")
            return None
    
    # LOGIN
    
    def login(self, dependencia: str, password: str) -> Outcome:
        """
        Realiza login con reintentos dinámicos y tolerancia a delays.
        Espera hasta 30 segundos a que aparezca la ventana de login.
        Retorna OK_RC si login OK, FAIL_LOGIN_PASSWORD si hay error.
        """

        try:
            self.logger.info("Iniciando proceso de login...")
            
            # Esperar ventana de login con reintentos dinámicos
            self.logger.info("Esperando ventana de login (hasta 60 segundos)...")
            dlg = None
            
            desktop = Desktop(backend=MSAA_BACKEND)
            start_time = time.time()
            timeout = 60  # Aumentado de 30 a 60 segundos para dar más tiempo a la app
            
            while time.time() - start_time < timeout:
                try:
                    # Búsqueda exacta: ventana con título exacto "SIRAT"
                    windows = desktop.windows()
                    
                    for window in windows:
                        try:
                            title = str(window.element_info.name or "")
                            # Búsqueda por exactitud: solo "SIRAT"
                            if title == "SIRAT":
                                dlg = window
                                self.logger.info(f"Ventana SIRAT encontrada")
                                break
                        except Exception:
                            continue
                    
                    if dlg:
                        break
                    
                except Exception as e:
                    self.logger.debug(f"Error buscando ventana SIRAT: {e}")
                    pass
                
                time.sleep(0.5)
            
            if dlg is None:
                self.logger.error("No se pudo encontrar la ventana SIRAT después de 60 segundos")
                return Outcome.FAIL_UI
            
            time.sleep(1)
            
            # Buscar campos de entrada por class="Edit" con timeout de 30 segundos
            self.logger.info("Buscando campos de dependencia y contraseña por class='Edit' (timeout: 30 seg)...")
            dependencia_field = None
            password_field = None
            
            start_search_time = time.time()
            search_timeout = 30  # 30 segundos
            
            try:
                # Localizar por class_name="Edit" - método directo y rápido con reintentos por timeout
                while time.time() - start_search_time < search_timeout:
                    if not dependencia_field or not password_field:
                        try:
                            edit_fields = []
                            try:
                                # Intentar acceder a descendants()
                                for element in dlg.descendants():
                                    try:
                                        class_name = getattr(element.element_info, 'class_name', '')
                                        if class_name == "Edit":
                                            edit_fields.append(element)
                                    except Exception:
                                        continue
                            except Exception as e:
                                # Si falla descendants(), usar método alternativo
                                self.logger.debug(f"descendants() falló: {e}, usando alternativa...")
                                try:
                                    edit_fields = [e for e in dlg.descendants(control_type="Edit")]
                                except Exception:
                                    pass
                            
                            if len(edit_fields) >= 2:
                                dependencia_field = edit_fields[0]
                                password_field = edit_fields[1]
                                self.logger.info(f"Campos encontrados por class='Edit': {len(edit_fields)} campos")
                                break
                        except Exception as e:
                            self.logger.debug(f"Reintentando búsqueda por class='Edit': {e}")
                            time.sleep(0.3)
                    else:
                        break
                
                if time.time() - start_search_time >= search_timeout:
                    self.logger.warning(f"Timeout de {search_timeout}s alcanzado buscando campos por class='Edit'")
            
            except Exception as e:
                self.logger.warning(f"Error al buscar campos por class='Edit': {e}")
            
            # Fallback: si no se encontraron por class="Edit", usar los primeros 2 Edit fields
            if not dependencia_field or not password_field:
                try:
                    self.logger.info("Fallback 1: buscando campos Edit por control_type...")
                    try:
                        edit_fields = [e for e in dlg.descendants(control_type="Edit")]
                    except Exception as e:
                        self.logger.debug(f"Fallback 1 error: {e}, intentando alternativa...")
                        edit_fields = []
                        for element in dlg.descendants():
                            try:
                                if getattr(element.element_info, 'control_type', None) == "Edit":
                                    edit_fields.append(element)
                            except Exception:
                                continue
                    
                    if len(edit_fields) >= 2:
                        if not dependencia_field:
                            dependencia_field = edit_fields[0]
                            self.logger.info("Usando primer campo Edit como dependencia")
                        if not password_field:
                            password_field = edit_fields[1]
                            self.logger.info("Usando segundo campo Edit como contraseña")
                except Exception as e:
                    self.logger.warning(f"Error en fallback 1: {e}")
            
            # Fallback 2: búsqueda alternativa
            if not dependencia_field or not password_field:
                try:
                    self.logger.info("Fallback 2: búsqueda manual de Edit fields...")
                    edit_fields = []
                    for element in dlg.descendants():
                        try:
                            class_name = getattr(element.element_info, 'class_name', '')
                            control_type = getattr(element.element_info, 'control_type', '')
                            if class_name == "Edit" or control_type == "Edit":
                                edit_fields.append(element)
                        except Exception:
                            continue
                    
                    if len(edit_fields) >= 2:
                        if not dependencia_field:
                            dependencia_field = edit_fields[0]
                            self.logger.info("Fallback 2: Usando primer campo Edit como dependencia")
                        if not password_field:
                            password_field = edit_fields[1]
                            self.logger.info("Fallback 2: Usando segundo campo Edit como contraseña")
                except Exception as e:
                    self.logger.warning(f"Error en fallback 2: {e}")
            
            if dependencia_field is None or password_field is None:
                self.logger.error("No se pudieron localizar los campos de login")
                return Outcome.FAIL_UI
            
            # Preparar texto completo de dependencia para el login
            dep_code = str(dependencia).strip()
            dep_map = {
                "21": "0021 I.R. Lima - PRICO",
                "23": "0023 I.R. Lima - MEPECO",
            }
            login_dep = dep_map.get(dep_code, dependencia)

            # Ingresar dependencia (escribimos el nombre completo y luego TAB)
            self.logger.info(f"Ingresando dependencia para login: {login_dep}")
            try:
                dependencia_field.set_focus()
                self.logger.info(f"  └─ Set focus en campo DEPENDENCIA")
                time.sleep(0.2)
                self.logger.info(f"  └─ Escribiendo: '{login_dep}' (0.02s entre caracteres)")
                pyautogui.write(login_dep, interval=0.02)
                time.sleep(0.2)
                self.logger.info(f"  └─ Presionando TAB para avanzar a CONTRASEÑA")
                pyautogui.press('tab')
                self.logger.info(f"  └─ Esperando 0.3s después de TAB")
                time.sleep(0.3)
            except Exception:
                # Fallback: si no es posible set_focus, intentar escribir directamente
                self.logger.info(f"  └─ [FALLBACK] Set focus falló, escribiendo directamente")
                pyautogui.write(login_dep, interval=0.02)
                pyautogui.press('tab')
                time.sleep(0.3)

            # Ingresar contraseña (después de TAB debería estar en el campo)
            self.logger.info("Ingresando contraseña...")
            
            # Verificar y desactivar Bloq Mayús antes de escribir la contraseña
            self.check_and_disable_capslock()
            
            try:
                self.logger.info(f"  └─ Escribiendo contraseña (0.02s entre caracteres)")
                pyautogui.write(password, interval=0.02)
                time.sleep(0.2)
            except Exception:
                # Fallback: si falla, intentar usar el control password_field
                try:
                    password_field.set_focus()
                    time.sleep(0.2)
                    self.logger.info(f"  └─ [FALLBACK] Set focus en campo contraseña")
                    pyautogui.write(password, interval=0.02)
                    time.sleep(0.2)
                except Exception:
                    self.logger.warning(" No se pudo ingresar la contraseña por los métodos habituales")
            
            # Hacer clic en Aceptar
            self.logger.info("Haciendo clic en Aceptar...")
            try:
                buttons = list(dlg.descendants(control_type="Button"))
                aceptar_btn = None
                for btn in buttons:
                    try:
                        btn_name = str(btn.element_info.name or "").lower()
                        if "aceptar" in btn_name or "ok" in btn_name:
                            aceptar_btn = btn
                            self.logger.info(f"  └─ Botón encontrado: '{btn.element_info.name}'")
                            break
                    except Exception:
                        continue
                
                if aceptar_btn:
                    self.logger.info(f"  └─ Invocando botón Aceptar")
                    aceptar_btn.invoke()
                else:
                    self.logger.info("  └─ Botón no encontrado, presionando ENTER...")
                    pyautogui.press('return')
            except Exception:
                self.logger.info("  └─ Presionando ENTER para confirmar...")
                pyautogui.press('return')
            
            # Pequeña pausa para que aparezca posible error
            time.sleep(1)
            
            # Verificar si hay mensaje de error de contraseña
            pwd_err, pwd_msg = self.detect_password_error(timeout=2.0)
            if pwd_err:
                self.logger.error(f" Contraseña incorrecta. Mensaje: {pwd_msg}")
                # Presionar ENTER para cerrar el aviso de error
                self.logger.info("  └─ Presionando ENTER para cerrar aviso de error")
                time.sleep(0.5)
                pyautogui.press('return')
                time.sleep(0.5)
                # Presionar ALT+C para seleccionar 'Cancelar' y cerrar la aplicación (solo en etapa de login)
                self.logger.info("  └─ Presionando ALT+C para cancelar login y cerrar la app...")
                try:
                    pyautogui.hotkey('alt', 'c')
                except Exception:
                    # En caso de que hotkey falle, intentar enviar secuencia alternativa
                    pyautogui.keyDown('alt')
                    pyautogui.press('c')
                    pyautogui.keyUp('alt')
                time.sleep(1)
                self.logger.info(" Cerrando aplicación debido a credenciales inválidas")
                return Outcome.FAIL_LOGIN_PASSWORD
            
            self.logger.info(" Login completado exitosamente")
            return Outcome.OK_RC
        
        except Exception as e:
            self.logger.error(f"Error en login: {e}")
            return Outcome.FAIL_UI

    # DETECTORES (copiados y adaptados de test2.py)
    def detect_password_error(self, timeout=2):
        try:
            self.logger.info("Verificando si hay mensaje de error...")
            desktop = Desktop(backend=MSAA_BACKEND)
            
            # Buscar ventana SIRAT primero (enfoque robusto)
            sirat_window = None
            try:
                sirat_window = desktop.window(title="SIRAT")
                if not sirat_window.exists(timeout=1):
                    sirat_window = None
            except Exception:
                sirat_window = None
            
            # Si no encuentra SIRAT, buscar todas las ventanas
            windows_to_check = [sirat_window] if sirat_window else desktop.windows()
            
            end_time = time.time() + timeout
            while time.time() < end_time:
                try:
                    for win in windows_to_check:
                        try:
                            all_descendants = list(win.descendants())
                            for desc in all_descendants:
                                try:
                                    control_type = None
                                    texto = ""
                                    try:
                                        if hasattr(desc, 'element_info'):
                                            control_type = desc.element_info.control_type
                                    except:
                                        pass
                                    try:
                                        texto = desc.window_text()
                                    except:
                                        pass
                                    if control_type == "Text" and texto and len(texto.strip()) > 0:
                                        texto_lower = texto.lower()
                                        palabras_clave = [
                                            "no puede ser accedido",
                                            "estimado usuario",
                                            "aplicativo",
                                            "credenciales",
                                            "error en las credenciales",
                                            "error numero"
                                        ]
                                        if any(palabra in texto_lower for palabra in palabras_clave):
                                            self.logger.error(f"Mensaje de error detectado: {texto}")
                                            return True, texto
                                except:
                                    pass
                        except:
                            pass
                except:
                    pass
                time.sleep(0.3)
            return False, ""
        except Exception as e:
            self.logger.error(f"Error en detect_password_error: {e}")
            return False, ""

    def detect_monto_aviso(self, timeout=2):
        try:
            self.logger.info("Verificando si hay mensaje de aviso del MONTO...")
            desktop = Desktop(backend=MSAA_BACKEND)
            
            # Buscar ventana SIRAT primero (enfoque robusto)
            sirat_window = None
            try:
                sirat_window = desktop.window(title="SIRAT")
                if not sirat_window.exists(timeout=1):
                    sirat_window = None
            except Exception:
                sirat_window = None
            
            # Si no encuentra SIRAT, buscar todas las ventanas
            windows_to_check = [sirat_window] if sirat_window else desktop.windows()
            
            end_time = time.time() + timeout
            while time.time() < end_time:
                try:
                    for win in windows_to_check:
                        try:
                            all_descendants = list(win.descendants())
                            for desc in all_descendants:
                                try:
                                    control_type = None
                                    texto = ""
                                    try:
                                        if hasattr(desc, 'element_info'):
                                            control_type = desc.element_info.control_type
                                    except:
                                        pass
                                    try:
                                        texto = desc.window_text()
                                    except:
                                        pass
                                    if control_type == "Text" and texto and len(texto.strip()) > 0:
                                        texto_lower = texto.lower()
                                        palabras_clave = [
                                            "monto",
                                            "excede",
                                            "saldo",
                                            "expediente",
                                            "aviso",
                                            "error"
                                        ]
                                        if any(palabra in texto_lower for palabra in palabras_clave):
                                            self.logger.info(f"Mensaje de aviso detectado: {texto}")
                                            return True, texto
                                except:
                                    pass
                        except:
                            pass
                except:
                    pass
                time.sleep(0.3)
            return False, ""
        except Exception as e:
            self.logger.error(f"Error en detect_monto_aviso: {e}")
            return False, ""

    def detect_expediente_error(self, timeout=2):
        try:
            self.logger.info("Verificando si hay mensaje de error de expediente...")
            desktop = Desktop(backend=MSAA_BACKEND)
            
            # Buscar ventana SIRAT primero (enfoque robusto)
            sirat_window = None
            try:
                sirat_window = desktop.window(title="SIRAT")
                if not sirat_window.exists(timeout=1):
                    sirat_window = None
            except Exception:
                sirat_window = None
            
            # Si no encuentra SIRAT, buscar todas las ventanas
            windows_to_check = [sirat_window] if sirat_window else desktop.windows()
            
            end_time = time.time() + timeout
            while time.time() < end_time:
                try:
                    for win in windows_to_check:
                        try:
                            all_descendants = list(win.descendants())
                            for desc in all_descendants:
                                try:
                                    control_type = None
                                    texto = ""
                                    try:
                                        if hasattr(desc, 'element_info'):
                                            control_type = desc.element_info.control_type
                                    except:
                                        pass
                                    try:
                                        texto = desc.window_text()
                                    except:
                                        pass
                                    if control_type == "Text" and texto and len(texto.strip()) > 0:
                                        texto_lower = texto.lower()
                                        # Buscar SOLO el mensaje específico de expediente inválido
                                        # y evitar texto muy largo (falsos positivos)
                                        if len(texto) < 200 and "expediente" in texto_lower and ("válido" in texto_lower or "no es valido" in texto_lower):
                                            self.logger.warning(f"Error de expediente detectado: {texto}")
                                            return True, texto
                                except:
                                    pass
                        except:
                            pass
                except:
                    pass
                time.sleep(0.3)
            return False, ""
        except Exception as e:
            self.logger.error(f"Error en detect_expediente_error: {e}")
            return False, ""

    def detect_expediente_aviso(self, timeout=2):
        """
        Detecta el aviso de embargos activos en DSE.
        Patrón: "El Expediente [NUM] correspondiente al RUC [NUM] tiene [NUM] Embargos activos..."
        Los números pueden variar, busca las palabras clave.
        """
        try:
            self.logger.info("Verificando aviso de embargos activos (expediente+ruc+embargo)...")
            desktop = Desktop(backend=MSAA_BACKEND)
            end_time = time.time() + timeout
            
            while time.time() < end_time:
                try:
                    for win in desktop.windows():
                        try:
                            for desc in win.descendants():
                                try:
                                    texto = str(desc.window_text() or "").strip()
                                    texto_lower = texto.lower()
                                    
                                    # Buscar patrón: debe contener las 4 palabras clave
                                    # (independiente de números específicos)
                                    if ("expediente" in texto_lower and 
                                        "ruc" in texto_lower and 
                                        "embargo" in texto_lower and 
                                        "activo" in texto_lower):
                                        self.logger.info(f" Aviso embargos activos: {texto[:80]}...")
                                        return True, texto
                                except Exception:
                                    pass
                        except Exception:
                            pass
                except Exception:
                    pass
                time.sleep(0.3)
            
            return False, ""
        except Exception as e:
            self.logger.error(f"Error en detect_expediente_aviso: {e}")
            return False, ""

    def handle_dse_embargo_aviso(self, timeout=2) -> bool:
        """
        Detecta el aviso de embargos activos en DSE que aparece después del doble clic.
        Mensaje esperado: "El Expediente XXX correspondiente al RUC xxx tiene x Embargos activos..."
        Si se detecta, presiona Alt+S para continuar.
        
        Returns:
            True si se detectó y respondió al aviso (o no hay aviso)
            False si hay un error crítico
        """
        try:
            self.logger.info("Verificando si hay aviso de embargos activos (DSE)...")
            desktop = Desktop(backend=MSAA_BACKEND)
            end_time = time.time() + timeout
            
            while time.time() < end_time:
                try:
                    all_windows = desktop.windows()
                    for win in all_windows:
                        try:
                            all_descendants = list(win.descendants())
                            for desc in all_descendants:
                                try:
                                    control_type = None
                                    texto = ""
                                    try:
                                        if hasattr(desc, 'element_info'):
                                            control_type = desc.element_info.control_type
                                    except:
                                        pass
                                    try:
                                        texto = desc.window_text()
                                    except:
                                        pass
                                    
                                    if control_type == "Text" and texto and len(texto.strip()) > 0:
                                        texto_strip = texto.strip()
                                        # Búsqueda: comienza con "El Expediente" y contiene "embargo"
                                        if (texto_strip.startswith("El Expediente") and 
                                            "embargo" in texto_strip.lower() and
                                            "activo" in texto_strip.lower()):
                                            self.logger.info(f" Aviso de embargos activos detectado")
                                            self.logger.info(f"Mensaje: {texto_strip[:100]}...")
                                            # Presionar Alt+S para continuar
                                            self.logger.info("Presionando Alt+S para continuar...")
                                            pyautogui.hotkey('alt', 's')
                                            time.sleep(1)
                                            self.logger.info(" Alt+S presionado")
                                            return True
                                except:
                                    pass
                        except:
                            pass
                except:
                    pass
                time.sleep(0.3)
            
            # No se detectó aviso (es normal si no hay embargos activos)
            self.logger.info("No se detectó aviso de embargos activos")
            return True
        
        except Exception as e:
            self.logger.error(f"Error en handle_dse_embargo_aviso: {e}")
            return False

    def handle_iei_embargo_aviso(self, timeout=2) -> bool:
        """
        Detecta el aviso de embargos activos en IEI que aparece después del doble clic.
        Mensaje esperado: "El Expediente XXX correspondiente al RUC xxx tiene x Embargos activos..."
        Si se detecta, presiona Alt+S para continuar.
        
        Returns:
            True si se detectó y respondió al aviso (o no hay aviso)
            False si hay un error crítico
        """
        try:
            self.logger.info("Verificando si hay aviso de embargos activos (IEI)...")
            desktop = Desktop(backend=MSAA_BACKEND)
            end_time = time.time() + timeout
            
            while time.time() < end_time:
                try:
                    all_windows = desktop.windows()
                    for win in all_windows:
                        try:
                            all_descendants = list(win.descendants())
                            for desc in all_descendants:
                                try:
                                    control_type = None
                                    texto = ""
                                    try:
                                        if hasattr(desc, 'element_info'):
                                            control_type = desc.element_info.control_type
                                    except:
                                        pass
                                    try:
                                        texto = desc.window_text()
                                    except:
                                        pass
                                    
                                    if control_type == "Text" and texto and len(texto.strip()) > 0:
                                        texto_strip = texto.strip()
                                        # Búsqueda: comienza con "El Expediente" y contiene "embargo"
                                        if (texto_strip.startswith("El Expediente") and 
                                            "embargo" in texto_strip.lower() and
                                            "activo" in texto_strip.lower()):
                                            self.logger.info(f" Aviso de embargos activos detectado (IEI)")
                                            self.logger.info(f"Mensaje: {texto_strip[:100]}...")
                                            # Presionar Alt+S para continuar
                                            self.logger.info("Presionando Alt+S para continuar...")
                                            pyautogui.hotkey('alt', 's')
                                            time.sleep(1)
                                            self.logger.info(" Alt+S presionado")
                                            return True
                                except:
                                    pass
                        except:
                            pass
                except:
                    pass
                time.sleep(0.3)
            
            # No se detectó aviso (es normal si no hay embargos activos)
            self.logger.info("No se detectó aviso de embargos activos (IEI)")
            return True
        
        except Exception as e:
            self.logger.error(f"Error en handle_iei_embargo_aviso: {e}")
            return False

    def extract_ruc_from_message(self, mensaje):
        try:
            self.logger.info("Extrayendo RUC del mensaje...")
            ruc_index = mensaje.upper().find("RUC")
            if ruc_index == -1:
                self.logger.warning("No se encontró 'RUC' en el mensaje")
                return ""
            texto_despues_ruc = mensaje[ruc_index + 3:].strip()
            self.logger.info(f"Texto después de 'RUC': '{texto_despues_ruc[:50]}'")
            ruc = ""
            for caracter in texto_despues_ruc:
                if caracter.isdigit():
                    ruc += caracter
                elif ruc:
                    break
            if ruc:
                self.logger.info(f" RUC extraído: {ruc}")
                return ruc
            else:
                self.logger.warning("No se encontraron dígitos después de 'RUC'")
                return ""
        except Exception as e:
            self.logger.error(f"Error extrayendo RUC: {e}")
            return ""

    def detect_resolucion_coactiva_aviso(self, timeout=2):
        try:
            self.logger.info("Verificando si hay mensaje de Resolución Coactiva...")
            desktop = Desktop(backend=MSAA_BACKEND)
            end_time = time.time() + timeout
            while time.time() < end_time:
                try:
                    all_windows = desktop.windows()
                    for win in all_windows:
                        try:
                            all_descendants = list(win.descendants())
                            for desc in all_descendants:
                                try:
                                    control_type = None
                                    texto = ""
                                    try:
                                        if hasattr(desc, 'element_info'):
                                            control_type = desc.element_info.control_type
                                    except:
                                        pass
                                    try:
                                        texto = desc.window_text()
                                    except:
                                        pass
                                    if control_type == "Text" and texto and len(texto.strip()) > 0:
                                        if "se grabó" in texto.lower() and "resolución coactiva" in texto.lower():
                                            self.logger.warning(f" MENSAJE DE RESOLUCIÓN COACTIVA DETECTADO: {texto[:100]}...")
                                            return True, texto
                                except:
                                    pass
                        except:
                            pass
                except:
                    pass
                time.sleep(0.3)
            return False, ""
        except Exception as e:
            self.logger.error(f"Error en detect_resolucion_coactiva_aviso: {e}")
            return False, ""

    def extract_resolucion_coactiva_number(self, mensaje):
        try:
            self.logger.info("Extrayendo número de Resolución Coactiva del mensaje...")
            numero_index = mensaje.lower().find("número")
            if numero_index == -1:
                self.logger.warning("No se encontró 'palabra 'número' en el mensaje")
                return ""
            texto_despues_numero = mensaje[numero_index + 6:].strip()
            self.logger.info(f"Texto después de 'número': '{texto_despues_numero[:50]}'")
            rc_number = ""
            for caracter in texto_despues_numero:
                if caracter.isdigit():
                    rc_number += caracter
                elif rc_number:
                    break
            if rc_number:
                self.logger.info(f" Número de RC extraído: {rc_number}")
                return rc_number
            else:
                self.logger.warning("No se encontraron dígitos después de 'número'")
                return ""
        except Exception as e:
            self.logger.error(f"Error extrayendo número de RC: {e}")
            return ""

    def detect_desea_continuar_aviso(self, timeout=2):
        try:
            self.logger.info("Verificando si hay mensaje '¿ Desea Continuar ?'...")
            desktop = Desktop(backend=MSAA_BACKEND)
            end_time = time.time() + timeout
            while time.time() < end_time:
                try:
                    dlgs = desktop.windows()
                    for dlg in dlgs:
                        try:
                            descendants = dlg.descendants()
                            for desc in descendants:
                                try:
                                    # Filtrar solo controles de tipo "Text"
                                    control_type = None
                                    texto = ""
                                    
                                    try:
                                        if hasattr(desc, 'element_info'):
                                            control_type = desc.element_info.control_type
                                    except:
                                        pass
                                    
                                    try:
                                        texto = desc.window_text()
                                    except:
                                        pass
                                    
                                    # Solo procesar controles de tipo "Text"
                                    if control_type == "Text" and texto:
                                        texto_lower = texto.lower()
                                        if "desea" in texto_lower and "continuar" in texto_lower:
                                            self.logger.warning(f"Aviso '¿ Desea Continuar ?' detectado")
                                            return True, texto
                                except Exception:
                                    pass
                        except Exception:
                            pass
                except Exception:
                    pass
                time.sleep(0.1)
            return False, ""
        except Exception as e:
            self.logger.error(f"Error en detect_desea_continuar_aviso: {e}")
            return False, ""

    def detect_interventor_error(self, timeout=2):
        """
        OPTIMIZADO: Detecta error de interventor buscando SOLO en SIRAT + controles Text
        
        PROBLEMA ORIGINAL:
        - Buscaba en TODO desktop (10+ ventanas) + ALL descendants (100+)
        - En producción: 24 segundos (bloqueaba digitación de PLAZO)
        
        SOLUCIÓN:
        - Busca SOLO en ventana SIRAT (confirmado via test_descendientes.py)
        - Busca SOLO en controles de tipo "Text" (más preciso y rápido)
        - Timeout: 0.5s (suficiente para detectar mensaje)
        - Esperado: 0.5 segundos vs 24 segundos
        
        Retorna: (True, "mensaje") si error detectado, (False, "") si no
        """
        try:
            self.logger.info(f"Verificando error 'Código de Interventor incorrecto' en controles Text (timeout={timeout}s)...")
            
            end_time = time.time() + timeout
            while time.time() < end_time:
                try:
                    # OPTIMIZACIÓN CLAVE: Solo buscar en SIRAT (no todo desktop)
                    sirat_window = self.find_sirat_window()
                    if not sirat_window:
                        time.sleep(0.05)
                        continue
                    
                    # Buscar descendants solo dentro de SIRAT
                    try:
                        descendants = sirat_window.descendants()
                        for desc in descendants:
                            try:
                                control_type = None
                                texto = ""
                                
                                # Obtener tipo de control
                                try:
                                    if hasattr(desc, 'element_info'):
                                        control_type = desc.element_info.control_type
                                except Exception:
                                    pass
                                
                                # Obtener texto
                                try:
                                    texto = desc.window_text()
                                except Exception:
                                    pass
                                
                                # FILTRO: Solo controles de tipo "Text" con contenido
                                if control_type == "Text" and texto and len(texto.strip()) > 0:
                                    texto_lower = texto.lower()
                                    # Búsqueda de 3 palabras clave
                                    if ("codigo" in texto_lower and 
                                        "interventor" in texto_lower and 
                                        "incorrecto" in texto_lower):
                                        self.logger.warning(f" Error INTERVENTOR detectado: '{texto}'")
                                        return True, texto
                            except Exception:
                                pass
                    except Exception:
                        pass
                
                except Exception:
                    pass
                
                time.sleep(0.05)  # Polling rápido (50ms intervals)
            
            self.logger.info("No hay error de INTERVENTOR")
            return False, ""
        except Exception as e:
            self.logger.error(f"Error en detect_interventor_error: {e}")
            return False, ""
            return False, ""

    def detect_grupo_funcionario_aviso(self, timeout=0.5) -> bool:
        """
        OPTIMIZADO: Detecta aviso "Debe Seleccionar un Grupo de Funcionario" en SIRAT + Text controls
        
        Significa que el expediente es válido pero no tiene ejecutor asignado.
        
        PROBLEMA ORIGINAL:
        - Buscaba en TODO desktop (10+ ventanas) + ALL descendants (100+)
        
        SOLUCIÓN:
        - Busca SOLO en ventana SIRAT (confirmado via test_descendientes.py)
        - Busca SOLO en controles de tipo "Text" (más preciso y rápido)
        - Timeout: 0.5s
        
        Returns: True si detecta el aviso, False si no
        """
        try:
            self.logger.info(f"Verificando aviso 'Grupo Funcionario' en controles Text (timeout={timeout}s)...")
            
            end_time = time.time() + timeout
            while time.time() < end_time:
                try:
                    # OPTIMIZACIÓN CLAVE: Solo buscar en SIRAT (no todo desktop)
                    sirat_window = self.find_sirat_window()
                    if not sirat_window:
                        time.sleep(0.05)
                        continue
                    
                    # Buscar descendants solo dentro de SIRAT
                    try:
                        descendants = sirat_window.descendants()
                        for desc in descendants:
                            try:
                                control_type = None
                                texto = ""
                                
                                # Obtener tipo de control
                                try:
                                    if hasattr(desc, 'element_info'):
                                        control_type = desc.element_info.control_type
                                except Exception:
                                    pass
                                
                                # Obtener texto
                                try:
                                    texto = str(desc.window_text() or "").strip()
                                except Exception:
                                    pass
                                
                                # FILTRO: Solo controles de tipo "Text" con contenido
                                if control_type == "Text" and texto and len(texto) > 0:
                                    texto_lower = texto.lower()
                                    
                                    if "debe seleccionar" in texto_lower and "grupo" in texto_lower and "funcionario" in texto_lower:
                                        self.logger.warning(f" Aviso 'Grupo Funcionario' detectado: '{texto}'")
                                        return True
                            except Exception:
                                pass
                    except Exception:
                        pass
                
                except Exception:
                    pass
                
                time.sleep(0.05)  # Polling rápido (50ms intervals)
            
            self.logger.info("No hay aviso de 'Grupo Funcionario'")
            return False
        
        except Exception as e:
            self.logger.error(f"Error en detect_grupo_funcionario_aviso: {e}")
            return False

    def handle_grupo_funcionario_aviso(self) -> bool:
        """
        Maneja el aviso "Debe Seleccionar un Grupo de Funcionario".
        
        Secuencia:
        1. Presionar ENTER para cerrar el aviso
        2. Presionar ALT+C para cerrar ventana
        3. Navegar a "Cobranza Coactiva" (click)
        4. Navegar a "Exp. Cob. Coactiva - Individual" (4 clics individuales)
        
        Retorna: True si se manejó exitosamente, False si falló
        """
        try:
            self.logger.warning("\n[MANEJO] Detectado aviso 'Grupo Funcionario' - iniciando procedimiento especial...")
            
            # PASO 1: Presionar ENTER para cerrar el aviso
            self.logger.info("[1/4] Presionando ENTER para cerrar aviso...")
            pyautogui.press('return')
            time.sleep(0.5)
            
            # PASO 2: Presionar ALT+C para cerrar ventana
            self.logger.info("[2/4] Presionando ALT+C para cerrar ventana...")
            pyautogui.hotkey('alt', 'c')
            time.sleep(1)
            
            # PASO 3: Hacer clic en "Cobranza Coactiva"
            self.logger.info("[3/4] Haciendo clic en 'Cobranza Coactiva'...")
            
            desktop = Desktop(backend=MSAA_BACKEND)
            max_intentos = 3
            
            for intento in range(1, max_intentos + 1):
                try:
                    app = None
                    try:
                        app = desktop.window(title="SIRAT")
                        if not app.exists(timeout=2):
                            app = None
                    except:
                        app = None
                    
                    if not app:
                        try:
                            app = desktop.active()
                        except:
                            app = None
                    
                    if not app:
                        self.logger.error(f"  Intento {intento}: No se encontró ventana SIRAT")
                        if intento < max_intentos:
                            time.sleep(0.5)
                            continue
                        return False
                    
                    # Buscar "Cobranza Coactiva"
                    try:
                        descendants = app.descendants()
                        cobranza_element = None
                        
                        for element in descendants:
                            try:
                                texto = (element.window_text() or "").strip()
                                if texto == "Cobranza Coactiva":
                                    cobranza_element = element
                                    break
                            except:
                                pass
                        
                        if not cobranza_element:
                            self.logger.warning(f"  Intento {intento}: 'Cobranza Coactiva' no encontrada")
                            if intento < max_intentos:
                                time.sleep(0.5)
                                continue
                            return False
                        
                        # Hacer clic en Cobranza Coactiva
                        rect = cobranza_element.rectangle()
                        if rect.width() <= 0 or rect.height() <= 0:
                            self.logger.warning(f"  Intento {intento}: Coordenadas inválidas")
                            if intento < max_intentos:
                                time.sleep(0.5)
                                continue
                            return False
                        
                        click_x = (rect.left + rect.right) // 2
                        click_y = (rect.top + rect.bottom) // 2
                        self.logger.info(f"  Coordenadas ({click_x}, {click_y})")
                        pyautogui.click(click_x, click_y)
                        self.logger.info("   Clic en Cobranza Coactiva completado")
                        time.sleep(0.5)
                        break  # Salir del loop
                    
                    except Exception as e:
                        self.logger.error(f"  Intento {intento}: Error buscando Cobranza Coactiva: {e}")
                        if intento < max_intentos:
                            time.sleep(0.5)
                            continue
                        return False
                
                except Exception as e:
                    self.logger.error(f"  Intento {intento}: Error general: {e}")
                    if intento < max_intentos:
                        time.sleep(0.5)
                        continue
                    return False
            
            # PASO 4: Hacer 4 clics en "Exp. Cob. Coactiva - Individual"
            self.logger.info("[4/4] Haciendo 4 clics en 'Exp. Cob. Coactiva - Individual'...")
            
            for intento in range(1, max_intentos + 1):
                try:
                    app = None
                    try:
                        app = desktop.window(title="SIRAT")
                        if not app.exists(timeout=2):
                            app = None
                    except:
                        app = None
                    
                    if not app:
                        try:
                            app = desktop.active()
                        except:
                            app = None
                    
                    if not app:
                        self.logger.error(f"  Intento {intento}: No se encontró ventana SIRAT")
                        if intento < max_intentos:
                            time.sleep(0.5)
                            continue
                        return False
                    
                    # Buscar "Exp. Cob. Coactiva - Individual"
                    try:
                        descendants = app.descendants()
                        individual_element = None
                        
                        for element in descendants:
                            try:
                                texto = (element.window_text() or "").strip()
                                if texto == "Exp. Cob. Coactiva - Individual":
                                    individual_element = element
                                    break
                            except:
                                pass
                        
                        if not individual_element:
                            self.logger.warning(f"  Intento {intento}: 'Exp. Cob. Coactiva - Individual' no encontrada")
                            if intento < max_intentos:
                                time.sleep(0.5)
                                continue
                            return False
                        
                        # Obtener coordenadas
                        rect = individual_element.rectangle()
                        if rect.width() <= 0 or rect.height() <= 0:
                            self.logger.warning(f"  Intento {intento}: Coordenadas inválidas")
                            if intento < max_intentos:
                                time.sleep(0.5)
                                continue
                            return False
                        
                        click_x = (rect.left + rect.right) // 2
                        click_y = (rect.top + rect.bottom) // 2
                        
                        # Hacer 4 clics individuales con intervalo de 0.3s
                        self.logger.info(f"  Coordenadas ({click_x}, {click_y})")
                        for i in range(1, 5):
                            pyautogui.click(click_x, click_y)
                            self.logger.info(f"    Clic {i}/4 completado")
                            time.sleep(0.3)
                        
                        self.logger.info("   4 clics completados")
                        time.sleep(1)
                        break  # Salir del loop
                    
                    except Exception as e:
                        self.logger.error(f"  Intento {intento}: Error buscando Individual: {e}")
                        if intento < max_intentos:
                            time.sleep(0.5)
                            continue
                        return False
                
                except Exception as e:
                    self.logger.error(f"  Intento {intento}: Error general: {e}")
                    if intento < max_intentos:
                        time.sleep(0.5)
                        continue
                    return False
            
            self.logger.warning("   Aviso 'Grupo Funcionario' manejado exitosamente")
            return True
        
        except Exception as e:
            self.logger.error(f"Error en handle_grupo_funcionario_aviso: {e}", exc_info=True)
            return False

    def handle_grupo_funcionario_en_cambio_expediente(self) -> bool:
        """
        Maneja el aviso "Debe Seleccionar un Grupo de Funcionario" cuando estamos en Cambio de Expediente.
        
        Este contexto es DIFERENTE al inicial. Aquí se navega:
        1. Presionar ENTER para cerrar el aviso
        2. Presionar ALT+C para cerrar ventana
        3. Hacer clic en "Accesos"
        4. Hacer doble clic en "Cambio de Expediente"
        
        Retorna: True si se manejó exitosamente, False si falló
        """
        try:
            self.logger.warning("\n[MANEJO] Detectado aviso 'Grupo Funcionario' en Cambio de Expediente...")
            
            # PASO 1: Presionar ENTER para cerrar el aviso
            self.logger.info("[1/4] Presionando ENTER para cerrar aviso...")
            pyautogui.press('return')
            time.sleep(0.5)
            
            # PASO 2: Presionar ALT+C para cerrar ventana
            self.logger.info("[2/4] Presionando ALT+C para cerrar ventana...")
            pyautogui.hotkey('alt', 'c')
            time.sleep(1)
            
            # PASO 3: Hacer clic en "Accesos"
            self.logger.info("[3/4] Haciendo clic en 'Accesos'...")
            
            desktop = Desktop(backend=MSAA_BACKEND)
            max_intentos = 3
            
            for intento in range(1, max_intentos + 1):
                try:
                    app = None
                    try:
                        app = desktop.window(title="SIRAT")
                        if not app.exists(timeout=2):
                            app = None
                    except:
                        app = None
                    
                    if not app:
                        try:
                            app = desktop.active()
                        except:
                            app = None
                    
                    if not app:
                        self.logger.error(f"  Intento {intento}: No se encontró ventana SIRAT")
                        if intento < max_intentos:
                            time.sleep(0.5)
                            continue
                        return False
                    
                    # Buscar "Accesos"
                    try:
                        descendants = app.descendants()
                        accesos_element = None
                        
                        for element in descendants:
                            try:
                                texto = (element.window_text() or "").strip()
                                if texto == "Accesos":
                                    accesos_element = element
                                    break
                            except:
                                pass
                        
                        if not accesos_element:
                            self.logger.warning(f"  Intento {intento}: 'Accesos' no encontrado")
                            if intento < max_intentos:
                                time.sleep(0.5)
                                continue
                            return False
                        
                        # Hacer clic en Accesos
                        rect = accesos_element.rectangle()
                        if rect.width() <= 0 or rect.height() <= 0:
                            self.logger.warning(f"  Intento {intento}: Coordenadas inválidas para 'Accesos'")
                            if intento < max_intentos:
                                time.sleep(0.5)
                                continue
                            return False
                        
                        click_x = (rect.left + rect.right) // 2
                        click_y = (rect.top + rect.bottom) // 2
                        self.logger.info(f"  Coordenadas ({click_x}, {click_y})")
                        pyautogui.click(click_x, click_y)
                        self.logger.info("   Clic en Accesos completado")
                        time.sleep(0.5)
                        time.sleep(1)
                        break  # Salir del loop
                    
                    except Exception as e:
                        self.logger.error(f"  Intento {intento}: Error buscando Accesos: {e}")
                        if intento < max_intentos:
                            time.sleep(0.5)
                            continue
                        return False
                
                except Exception as e:
                    self.logger.error(f"  Intento {intento}: Error general: {e}")
                    if intento < max_intentos:
                        time.sleep(0.5)
                        continue
                    return False
            
            # PASO 4: Hacer doble clic en "Cambio de Expediente"
            self.logger.info("[4/4] Haciendo doble clic en 'Cambio de Expediente'...")
            
            for intento in range(1, max_intentos + 1):
                try:
                    app = None
                    try:
                        app = desktop.window(title="SIRAT")
                        if not app.exists(timeout=2):
                            app = None
                    except:
                        app = None
                    
                    if not app:
                        try:
                            app = desktop.active()
                        except:
                            app = None
                    
                    if not app:
                        self.logger.error(f"  Intento {intento}: No se encontró ventana SIRAT")
                        if intento < max_intentos:
                            time.sleep(0.5)
                            continue
                        return False
                    
                    # Buscar "Cambio de Expediente"
                    try:
                        descendants = app.descendants()
                        cambio_element = None
                        
                        for element in descendants:
                            try:
                                texto = (element.window_text() or "").strip()
                                if texto == "Cambio de Expediente":
                                    cambio_element = element
                                    break
                            except:
                                pass
                        
                        if not cambio_element:
                            self.logger.warning(f"  Intento {intento}: 'Cambio de Expediente' no encontrado")
                            if intento < max_intentos:
                                time.sleep(0.5)
                                continue
                            return False
                        
                        # Obtener coordenadas
                        rect = cambio_element.rectangle()
                        if rect.width() <= 0 or rect.height() <= 0:
                            self.logger.warning(f"  Intento {intento}: Coordenadas inválidas")
                            if intento < max_intentos:
                                time.sleep(0.5)
                                continue
                            return False
                        
                        click_x = (rect.left + rect.right) // 2
                        click_y = (rect.top + rect.bottom) // 2
                        
                        # Hacer doble clic
                        self.logger.info(f"  Coordenadas ({click_x}, {click_y})")
                        pyautogui.doubleClick(click_x, click_y)
                        self.logger.info("   Doble clic en Cambio de Expediente completado")
                        time.sleep(1)
                        break  # Salir del loop
                    
                    except Exception as e:
                        self.logger.error(f"  Intento {intento}: Error buscando Cambio de Expediente: {e}")
                        if intento < max_intentos:
                            time.sleep(0.5)
                            continue
                        return False
                
                except Exception as e:
                    self.logger.error(f"  Intento {intento}: Error general: {e}")
                    if intento < max_intentos:
                        time.sleep(0.5)
                        continue
                    return False
            
            self.logger.warning("   Aviso 'Grupo Funcionario' en Cambio de Expediente manejado exitosamente")
            return True
        
        except Exception as e:
            self.logger.error(f"Error en handle_grupo_funcionario_en_cambio_expediente: {e}", exc_info=True)

    def detect_aviso_monto_excede_20pct(self, timeout=2):
        """
        Detecta el aviso de monto excesivo en controles de tipo "Text":
        "El monto ingresado excede en mas del [X]% el Saldo del Expediente"
        Tolerante con cualquier porcentaje (20%, 10%, 15%, X%, etc).
        """
        try:
            self.logger.info("Verificando aviso 'monto excede porcentaje'...")
            desktop = Desktop(backend=MSAA_BACKEND)
            end_time = time.time() + timeout
            
            while time.time() < end_time:
                try:
                    for win in desktop.windows():
                        try:
                            for desc in win.descendants():
                                try:
                                    # Filtrar solo controles de tipo "Text"
                                    control_type = None
                                    texto = ""
                                    
                                    try:
                                        if hasattr(desc, 'element_info'):
                                            control_type = desc.element_info.control_type
                                    except:
                                        pass
                                    
                                    try:
                                        texto = str(desc.window_text() or "").strip()
                                    except:
                                        pass
                                    
                                    # Solo procesar controles de tipo "Text"
                                    if control_type == "Text" and texto:
                                        texto_lower = texto.lower()
                                        
                                        # Búsqueda tolerante con expresión regular para cualquier porcentaje
                                        import re
                                        has_excede = "excede" in texto_lower
                                        has_percent = bool(re.search(r'\d+\s*%', texto))
                                        has_saldo = "saldo" in texto_lower
                                        has_expediente = "expediente" in texto_lower
                                        
                                        if has_excede and has_percent and has_saldo and has_expediente:
                                            self.logger.info(f" Aviso monto excede: {texto[:80]}...")
                                            return True, texto
                                except Exception:
                                    pass
                        except Exception:
                            pass
                except Exception:
                    pass
                time.sleep(0.3)
            
            return False, ""
        except Exception as e:
            self.logger.error(f"Error en detect_aviso_monto_excede_20pct: {e}")
            return False, ""

    def detect_aviso_monto_supera_saldo(self, timeout=2):
        """
        Detecta el aviso de monto excesivo en controles de tipo "Text":
        "El monto de embargo ingresado supera el saldo embargable del expediente..."
        Tolerante con variación de texto y números.
        """
        try:
            self.logger.info("Verificando aviso 'monto supera saldo'...")
            desktop = Desktop(backend=MSAA_BACKEND)
            end_time = time.time() + timeout
            
            while time.time() < end_time:
                try:
                    for win in desktop.windows():
                        try:
                            for desc in win.descendants():
                                try:
                                    # Filtrar solo controles de tipo "Text"
                                    control_type = None
                                    texto = ""
                                    
                                    try:
                                        if hasattr(desc, 'element_info'):
                                            control_type = desc.element_info.control_type
                                    except:
                                        pass
                                    
                                    try:
                                        texto = str(desc.window_text() or "").strip()
                                    except:
                                        pass
                                    
                                    # Solo procesar controles de tipo "Text"
                                    if control_type == "Text" and texto:
                                        texto_lower = texto.lower()
                                        
                                        # Búsqueda tolerante: palabras clave
                                        if ("monto" in texto_lower and
                                            "embargo" in texto_lower and
                                            "supera" in texto_lower and 
                                            "saldo" in texto_lower):
                                            self.logger.info(f" Aviso monto supera saldo: {texto[:80]}...")
                                            return True, texto
                                except Exception:
                                    pass
                        except Exception:
                            pass
                except Exception:
                    pass
                time.sleep(0.3)
            
            return False, ""
        except Exception as e:
            self.logger.error(f"Error en detect_aviso_monto_supera_saldo: {e}")
            return False, ""

    def detect_desea_grabar_resolucion(self, timeout=2):
        """
        Detecta el aviso de confirmación de grabación en controles de tipo "Text":
        "¿Desea Ud. grabar la Resolución?" (puede variar ligeramente)
        Tolerante con variaciones (resolucion, resolución, etc).
        """
        try:
            self.logger.info("Verificando aviso '¿Desea grabar Resolución?'...")
            desktop = Desktop(backend=MSAA_BACKEND)
            end_time = time.time() + timeout
            
            while time.time() < end_time:
                try:
                    for win in desktop.windows():
                        try:
                            for desc in win.descendants():
                                try:
                                    # Filtrar solo controles de tipo "Text"
                                    control_type = None
                                    texto = ""
                                    
                                    try:
                                        if hasattr(desc, 'element_info'):
                                            control_type = desc.element_info.control_type
                                    except:
                                        pass
                                    
                                    try:
                                        texto = str(desc.window_text() or "").strip()
                                    except:
                                        pass
                                    
                                    # Solo procesar controles de tipo "Text"
                                    if control_type == "Text" and texto:
                                        texto_lower = texto.lower()
                                        
                                        # Búsqueda tolerante: palabras clave
                                        if ("desea" in texto_lower and 
                                            "grabar" in texto_lower and 
                                            "resolu" in texto_lower):  # resolu cubre resolución, resolucion
                                            self.logger.info(f" Aviso grabar Resolución: {texto[:80]}...")
                                            return True, texto
                                except Exception:
                                    pass
                        except Exception:
                            pass
                except Exception:
                    pass
                time.sleep(0.3)
            
            return False, ""
        except Exception as e:
            self.logger.error(f"Error en detect_desea_grabar_resolucion: {e}")
            return False, ""

    def detect_rc_message(self, timeout=3):
        """
        OPTIMIZADO: Detecta "Se grabó la Resolución Coactiva" buscando SOLO en SIRAT
        
        Antes: Buscaba en TODO desktop (10+ ventanas) + ALL descendants (100+)
               = 20 segundos por intento
        
        Ahora: Busca SOLO en ventana SIRAT (confirmado via test_descendientes.py)
               = 1 segundo vs 20 segundos
        
        Retorna: (True, "numero_rc") si se detecta, (False, "") si no
        IMPORTANTE: Retorna número como STRING para preservar 0s iniciales
        """
        try:
            self.logger.info(f"Buscando RC en SIRAT: 'Se grabó la Resolución Coactiva' (timeout={timeout}s OPTIMIZADO)...")
            
            end_time = time.time() + timeout
            while time.time() < end_time:
                try:
                    # OPTIMIZACIÓN CLAVE: Solo buscar en SIRAT (no todo desktop)
                    sirat_window = self.find_sirat_window()
                    if not sirat_window:
                        time.sleep(0.1)
                        continue
                    
                    # Buscar descendants solo dentro de SIRAT
                    try:
                        all_descendants = list(sirat_window.descendants())
                        
                        for desc in all_descendants:
                            try:
                                control_type = None
                                texto = ""
                                
                                # Obtener tipo de control
                                try:
                                    if hasattr(desc, 'element_info'):
                                        control_type = desc.element_info.control_type
                                except Exception:
                                    pass
                                
                                # Obtener texto
                                try:
                                    texto = desc.window_text()
                                except Exception:
                                    pass
                                
                                # Filtrar: solo controles de tipo "Text" que contengan el patrón
                                if control_type == "Text" and texto and len(texto.strip()) > 0:
                                    texto_lower = texto.lower()
                                    
                                    # Buscar patrón "Se grabó la Resolución Coactiva"
                                    if "se grabó" in texto_lower and "resolución coactiva" in texto_lower:
                                        self.logger.info(f" Mensaje RC detectado: {texto[:100]}...")
                                        
                                        # Extraer número después de "número"
                                        numero_index = texto_lower.find("número")
                                        if numero_index >= 0:
                                            texto_despues = texto[numero_index + 6:].strip()
                                            
                                            # Extraer dígitos consecutivos
                                            rc_number = ""
                                            for char in texto_despues:
                                                if char.isdigit():
                                                    rc_number += char
                                                elif rc_number:  # Ya tenemos dígitos, paramos en primer no-dígito
                                                    break
                                            
                                            if rc_number:
                                                self.logger.info(f" RC extraída como STRING: {rc_number}")
                                                return True, rc_number
                            
                            except Exception:
                                pass
                    
                    except Exception:
                        pass
                
                except Exception:
                    pass
                
                time.sleep(0.1)
            
            self.logger.warning(f"No se detectó RC después de {timeout} segundos")
            return False, ""
        
        except Exception as e:
            self.logger.error(f"Error en detect_rc_message: {e}")
            return False, ""
    
    # NAVEGACIÓN BÁSICA
    
    def navigate_to_module(self) -> bool:
        """
        Navega a Cobranza Coactiva con reintentos (hasta 360 segundos).
        Solo busca dentro de la ventana SIRAT (la única ventana relevante).
        """
        try:
            self.logger.info("Buscando 'Cobranza Coactiva' dentro de ventana SIRAT...")
            
            timeout_segundos = 360
            tiempo_inicio = time.time()
            intento = 0
            
            while time.time() - tiempo_inicio < timeout_segundos:
                intento += 1
                tiempo_transcurrido = int(time.time() - tiempo_inicio)
                self.logger.info(f"Intento {intento} (tiempo: {tiempo_transcurrido}/{timeout_segundos}s)")
                
                try:
                    desktop = Desktop(backend=MSAA_BACKEND)
                    
                    # Obtener ventana SIRAT (ya debe estar abierta desde login)
                    app = desktop.window(title="SIRAT")
                    if not app.exists(timeout=2):
                        self.logger.info(f"Intento {intento}: ventana SIRAT no disponible, reintentando...")
                        time.sleep(2)
                        continue
                    
                    encontrado = False
                    
                    # Buscar "Cobranza Coactiva" solo dentro de la ventana SIRAT
                    try:
                        descendants = app.descendants()
                        for descendant in descendants:
                            try:
                                texto = (descendant.window_text() or "").strip()
                                if texto == "Cobranza Coactiva":
                                    self.logger.info("Elemento 'Cobranza Coactiva' encontrado, haciendo clic...")
                                    rect = descendant.rectangle()
                                    center_x = (rect.left + rect.right) // 2
                                    center_y = (rect.top + rect.bottom) // 2
                                    pyautogui.click(center_x, center_y)
                                    time.sleep(1)
                                    encontrado = True
                                    break
                            except Exception:
                                pass
                    except Exception as e:
                        self.logger.debug(f"Error buscando en descendientes: {e}")
                    
                    if encontrado:
                        self.logger.info(" Clic en 'Cobranza Coactiva' completado")
                        time.sleep(1)
                        # Ahora seleccionar 'Exp. Cob. Coactiva - Individual'
                        ok = self.click_exp_individual(app)
                        if ok:
                            return True
                        else:
                            self.logger.warning("No se pudo seleccionar 'Exp. Cob. Coactiva - Individual'")
                            return False
                    
                    self.logger.debug(f"Intento {intento}: 'Cobranza Coactiva' no encontrada en descendientes")
                    
                except Exception as e:
                    self.logger.debug(f"Error en intento {intento}: {e}")
                
                time.sleep(2)
            
            # Timeout alcanzado
            self.logger.error(f"Timeout alcanzado ({timeout_segundos}s) buscando 'Cobranza Coactiva'")
            return False
            
        except Exception as e:
            self.logger.error(f"Error navegando al módulo: {e}")
            return False
    
    def click_exp_individual(self, app=None):
        """
        Hace 4 clics en 'Exp. Cob. Coactiva - Individual'.
        Se llama DESPUÉS de navigate_to_module().
        Solo busca dentro de la ventana SIRAT (la única ventana relevante).
        
        Args:
            app: ventana SIRAT (si no se proporciona, se obtiene automáticamente)
        """
        try:
            self.logger.info("Haciendo 4 clics en 'Exp. Cob. Coactiva - Individual'...")
            
            # Si no se proporcionó ventana, obtener la ventana SIRAT
            if not app:
                try:
                    desktop = Desktop(backend=MSAA_BACKEND)
                    app = desktop.window(title="SIRAT")
                    if not app.exists(timeout=2):
                        self.logger.error("No se encontró ventana SIRAT")
                        return False
                except Exception:
                    self.logger.error("Error obteniendo ventana SIRAT")
                    return False
            
            # Buscar el control solo dentro de la ventana SIRAT
            target_element = None
            try:
                descendants = app.descendants()
                for element in descendants:
                    try:
                        texto = (element.window_text() or "").strip()
                        if texto == "Exp. Cob. Coactiva - Individual":
                            target_element = element
                            break
                    except Exception:
                        continue
            except Exception as e:
                self.logger.debug(f"Error buscando en descendientes: {e}")

            if not target_element:
                self.logger.warning("'Exp. Cob. Coactiva - Individual' no encontrado en ventana SIRAT")
                return False

            # Obtener coordenadas y hacer 4 clics
            try:
                rect = target_element.rectangle()
                center_x = (rect.left + rect.right) // 2
                center_y = (rect.top + rect.bottom) // 2
            except Exception:
                self.logger.warning("No se pudieron obtener coordenadas del control 'Exp. Individual'")
                return False

            self.logger.info(f"Encontrado: {target_element.window_text() or ''}")

            for i in range(4):
                pyautogui.click(center_x, center_y)
                self.logger.info(f"Clic {i+1}/4")
                time.sleep(0.3)

            self.logger.info(" Se completaron 4 clics en 'Exp. Cob. Coactiva - Individual'")
            return True

        except Exception as e:
            self.logger.error(f"Error en click_exp_individual: {e}")
            return False
    
    # ENTRADA DE EXPEDIENTES
    
    def enter_expediente_initial(self, expediente: str) -> Tuple[Outcome, Optional[str]]:
        """
        Ingresa el primer expediente (sin usar Accesos).
        Preserva ceros iniciales (ej: 029 no se convierte a 29).
        Retorna (Outcome, rc_si_aplica)
        """
        try:
            self.logger.info(f"Ingresando expediente inicial: {expediente}")
            
            # Verificar que SIRAT siga abierto
            if not self.check_app_window_exists():
                self.logger.error("[CRÍTICO] SIRAT se cerró o crasheó antes de ingresar expediente")
                return (Outcome.FAIL_UI, None)
            
            # Buscar campo PBEDIT flexible (soporta variantes PBEDIT124, PBEDIT125, etc.)
            numero_field = self._find_pbedit_field()
            
            if not numero_field:
                self.logger.error("No se encontró campo PBEDIT")
                return (Outcome.FAIL_UI, None)
            
            # Limpiar campo antes de digitar
            numero_field.set_focus()
            time.sleep(0.3)
            for _ in range(15):
                pyautogui.hotkey('ctrl', 'backspace')
                time.sleep(0.02)
            time.sleep(0.3)
            
            # Digitar expediente carácter por carácter para preservar ceros iniciales
            self.logger.info(f"Escribiendo expediente: {expediente}")
            self._type_string_preserving_zeros(expediente)
            time.sleep(0.5)
            
            # Presionar ENTER
            pyautogui.press('return')
            time.sleep(0.5)
            
            # Detectar error de expediente (esperar 0.5s)
            exp_err, exp_msg = self.detect_expediente_error(timeout=0.5)
            if exp_err:
                self.logger.warning(f"Expediente inválido: {exp_msg}")
                pyautogui.press('escape')
                time.sleep(0.5)
                return (Outcome.SKIP_EXP_INVALIDO, None)
            
            self.logger.info(f"Expediente ingresado: {expediente}")
            return (Outcome.OK_RC, None)  # OK_RC indica que pasó validación, no que hay RC
        
        except Exception as e:
            self.logger.error(f"Error ingresando expediente inicial: {e}")
            return (Outcome.FAIL_UI, None)
    
    def enter_expediente_change(self, expediente: str) -> Tuple[Outcome, Optional[str]]:
        """
        Ingresa expediente usando Accesos → Cambio de Expediente.
        Preserva ceros iniciales (ej: 029 no se convierte a 29).
        
        Secuencia:
        1. Digitar expediente
        2. Presionar TAB
        3. Verificar si aparece error de expediente inválido
        4. Presionar ALT+A para continuar
        5. Detectar y manejar el aviso "Debe Seleccionar un Grupo de Funcionario" si aparece
        
        Retorna (Outcome, rc_si_aplica)
        """
        try:
            self.logger.info(f"Ingresando expediente (con Cambio): {expediente}")
            
            # Verificar que SIRAT siga abierto
            if not self.check_app_window_exists():
                self.logger.error("[CRÍTICO] SIRAT se cerró o crasheó antes de ingresar expediente")
                return (Outcome.FAIL_UI, None)
            
            # Buscar campo PBEDIT flexible (soporta variantes PBEDIT124, PBEDIT125, etc.)
            numero_field = self._find_pbedit_field()
            
            if not numero_field:
                self.logger.error("No se encontro campo PBEDIT")
                return (Outcome.FAIL_UI, None)
            
            # Limpiar campo antes de digitar
            numero_field.set_focus()
            time.sleep(0.3)
            for _ in range(15):
                pyautogui.hotkey('ctrl', 'backspace')
                time.sleep(0.02)
            time.sleep(0.3)
            
            # Digitar expediente carácter por carácter para preservar ceros iniciales
            self.logger.info(f"Escribiendo expediente: {expediente}")
            self._type_string_preserving_zeros(expediente)
            time.sleep(0.5)
            
            # PASO 1: Presionar TAB (no ENTER como en el caso inicial)
            self.logger.info("Presionando TAB para validar expediente...")
            pyautogui.press('tab')
            time.sleep(0.5)
            
            # PASO 2: Detectar error de expediente inválido
            exp_err, exp_msg = self.detect_expediente_error(timeout=0.5)
            if exp_err:
                self.logger.warning(f"Expediente inválido: {exp_msg}")
                pyautogui.press('escape')
                time.sleep(0.5)
                return (Outcome.SKIP_EXP_INVALIDO, None)
            
            # PASO 3: Presionar ALT+A para continuar
            self.logger.info("Presionando ALT+A para continuar...")
            pyautogui.hotkey('alt', 'a')
            time.sleep(0.5)
            
            # PASO 4: Detectar aviso "Debe Seleccionar un Grupo de Funcionario"
            if self.detect_grupo_funcionario_aviso(timeout=0.5):
                self.logger.warning(f"Aviso 'Grupo Funcionario' detectado - ejecutando procedimiento especial...")
                
                if not self.handle_grupo_funcionario_en_cambio_expediente():
                    self.logger.error("Error manejando aviso de grupo funcionario en cambio de expediente")
                    return (Outcome.FAIL_UI, None)
                
                # Después de manejar el aviso, es un expediente sin grupo asignado (SKIP)
                return (Outcome.SKIP_EXP_INVALIDO, None)
            
            self.logger.info(f"Expediente ingresado: {expediente}")
            return (Outcome.OK_RC, None)
        
        except Exception as e:
            self.logger.error(f"Error ingresando expediente (cambio): {e}")
            return (Outcome.FAIL_UI, None)
    
    # NAVEGACIÓN ACCESOS
    
    def iter_all_descendants(self):
        """
        Generador que itera solo los descendientes de la ventana SIRAT.
        La ventana SIRAT es la única ventana relevante para la automatización.
        """
        try:
            desktop = Desktop(backend=MSAA_BACKEND)
            try:
                app = desktop.window(title="SIRAT")
                if app.exists(timeout=1):
                    for desc in app.descendants():
                        yield desc
            except Exception:
                pass
        except Exception:
            return
    
    def _find_pbedit_field(self) -> Optional[object]:
        """
        Busca campo PBEDIT de forma flexible, SOLO en la ventana SIRAT.
        Prioridad: PBEDIT125 (para expedientes) → PBEDIT124 → Otros PBEDIT* → Fallback Edit
        
        Retorna el elemento o None si no se encuentra (máximo 3 segundos).
        """
        try:
            desktop = Desktop(backend=MSAA_BACKEND)
            
            # Obtener ventana SIRAT (la única ventana relevante)
            try:
                app = desktop.window(title="SIRAT")
                if not app.exists(timeout=1):
                    return None
            except Exception:
                return None
            
            descendants = list(app.descendants())
            
            # Estrategia 1: Buscar PBEDIT125 específicamente (expedientes)
            self.logger.info("Buscando PBEDIT125 (campo estándar para expedientes)...")
            for element in descendants:
                try:
                    class_name = str(element.element_info.class_name or "").strip()
                    if class_name == "PBEDIT125":
                        self.logger.info(f"  {class_name} encontrado (estándar para expedientes)")
                        self.logger.info("[ ESTRATEGIA 1 FUNCIONÓ] PBEDIT125 encontrado - retornando")
                        return element
                except Exception:
                    continue
            self.logger.debug("[ ESTRATEGIA 1 FALLÓ] PBEDIT125 no encontrado")
            
            # Estrategia 2: Buscar otros PBEDIT* (PBEDIT124, etc.)
            self.logger.info("PBEDIT125 no encontrado, buscando otro PBEDIT*...")
            for element in descendants:
                try:
                    class_name = str(element.element_info.class_name or "").strip()
                    if class_name.startswith("PBEDIT"):
                        self.logger.info(f"  {class_name} encontrado (variante)")
                        self.logger.info(f"[ ESTRATEGIA 2 FUNCIONÓ] {class_name} encontrado - retornando")
                        return element
                except Exception:
                    continue
            self.logger.debug("[ ESTRATEGIA 2 FALLÓ] Ningún PBEDIT* encontrado")
            
            # Estrategia 3: Fallback - buscar por tipo Edit
            self.logger.info("PBEDIT* no encontrado, usando fallback (campo Edit)...")
            for element in descendants:
                try:
                    control_type = str(element.element_info.control_type or "")
                    if "Edit" in control_type or "text" in control_type.lower():
                        self.logger.info(f"  Campo editable encontrado por tipo: {control_type}")
                        self.logger.info("[ ESTRATEGIA 3 FUNCIONÓ] Campo Edit encontrado - retornando")
                        return element
                except Exception:
                    continue
            self.logger.debug("[ ESTRATEGIA 3 FALLÓ] Ningún campo Edit encontrado")
            
            return None
        except Exception as e:
            self.logger.debug(f"Error en _find_pbedit_field: {e}")
            return None
    
    def _type_string_preserving_zeros(self, text: str) -> None:
        """
        Escribe un string carácter por carácter para preservar ceros iniciales.
        Evita que pyautogui.write() interprete '029' como número 29.
        """
        text_str = str(text)  # Asegurar que es string
        for char in text_str:
            pyautogui.typewrite(char, interval=0.02)  # typewrite es más seguro para caracteres
        time.sleep(0.2)

    def go_to_accesos_change_expediente(self) -> bool:
        """Va a Accesos → Cambio de Expediente."""
        try:
            self.logger.info("Navegando a Accesos → Cambio de Expediente...")
            
            desktop = Desktop(backend=MSAA_BACKEND)
            
            # Click en Accesos
            for element in self.iter_all_descendants():
                try:
                    name = str(element.element_info.name or "").strip().lower()
                    if name == "accesos":
                        element.click()
                        self.logger.info("  Click en Accesos")
                        time.sleep(0.5)
                        break
                except Exception:
                    continue
            
            # Doble click en Cambio de Expediente
            for element in self.iter_all_descendants():
                try:
                    name = str(element.element_info.name or "").lower()
                    if "cambio" in name and "expediente" in name:
                        element.double_click()
                        self.logger.info("  Doble click en Cambio de Expediente")
                        time.sleep(0.5)
                        return True
                except Exception:
                    continue
            
            self.logger.warning("No se encontró Cambio de Expediente")
            return False
        
        except Exception as e:
            self.logger.error(f"Error navegando a Accesos: {e}")
            return False
    
    # NAVEGACIÓN EMBARGO - FUNCIONES SEPARADAS
    
    def click_proceso_embargo(self) -> bool:
        """
        Busca y hace clic en 'Proceso de Embargo' usando MSAA.
        Almacena las coordenadas para reutilizar después.
        """
        self.logger.info("Buscando 'Proceso de Embargo' en el menú...")
        
        try:
            desktop = Desktop(backend="uia")
            
            # Buscar ventana SIRAT
            app = None
            try:
                app = desktop.window(title_re=".*Menú.*")
                if not app.exists(timeout=2):
                    app = None
            except:
                app = None
            
            if not app:
                try:
                    app = desktop.window(title_re=".*SIRAT.*")
                    if not app.exists(timeout=2):
                        app = None
                except:
                    app = None
            
            if not app:
                try:
                    app = desktop.active()
                except:
                    app = None
            
            if app:
                self.logger.info("Ventana encontrada, iterando descendientes...")
                
                try:
                    descendants = app.descendants()
                    self.logger.info(f"Total de descendientes: {len(descendants)}")
                    
                    for idx, descendant in enumerate(descendants):
                        try:
                            desc_text = descendant.window_text().strip()
                            
                            # Búsqueda exacta: "Proceso de Embargo"
                            if desc_text == "Proceso de Embargo":
                                self.logger.info(f" 'Proceso de Embargo' encontrado en índice {idx}")
                                rect = descendant.rectangle()
                                
                                if rect.width() > 0 and rect.height() > 0:
                                    click_x = (rect.left + rect.right) // 2
                                    click_y = (rect.top + rect.bottom) // 2
                                    self.logger.info(f"Coordenadas válidas: ({click_x}, {click_y})")
                                    
                                    # Guardar coordenadas para reutilizar después
                                    self.proceso_embargo_coords = (click_x, click_y)
                                    self.logger.info(f" Coordenadas de 'Proceso de Embargo' guardadas: {self.proceso_embargo_coords}")
                                    
                                    pyautogui.click(click_x, click_y)
                                    self.logger.info("Esperando 2 segundos para que se expanda el menú...")
                                    time.sleep(2)
                                    self.logger.info(" Clic en Proceso de Embargo completado")
                                    return True
                        
                        except Exception:
                            pass
                
                except Exception as e:
                    self.logger.warning(f"Error iterando descendientes: {e}")
            
            self.logger.warning("No se pudo encontrar 'Proceso de Embargo'")
            return False
        
        except Exception as e:
            self.logger.error(f"Error en click_proceso_embargo: {e}")
            return False
    
    def click_trabar_embargo(self) -> bool:
        """
        Busca y hace clic en 'Trabar Embargo' usando MSAA.
        Almacena las coordenadas para reutilizar después.
        El elemento tiene espacios en blanco al final que se eliminan con strip().
        
        Estrategia: Búsqueda directa en descendientes (v3 - PROBADO Y FUNCIONABLE)
        """
        self.logger.info("Buscando 'Trabar Embargo' (usando patrón de descendientes)...")
        
        try:
            desktop = Desktop(backend="uia")
            
            # Buscar ventana SIRAT
            app = None
            try:
                app = desktop.window(title_re=".*SIRAT.*")
                if not app.exists(timeout=2):
                    app = None
            except:
                app = None
            
            if not app:
                try:
                    app = desktop.active()
                except:
                    app = None
            
            if app:
                self.logger.info("Ventana encontrada, iterando descendientes...")
                
                try:
                    descendants = app.descendants()
                    self.logger.info(f"Total de descendientes: {len(descendants)}")
                    
                    # Listas para debugging
                    elementos_embargo = []
                    elementos_trabar = []
                    
                    # Iterar todos los descendientes y buscar "Trabar Embargo"
                    for i, descendant in enumerate(descendants):
                        try:
                            desc_text = descendant.window_text().strip()
                            
                            # Recolectar elementos relevantes para debugging
                            if "embargo" in desc_text.lower():
                                elementos_embargo.append((i, desc_text))
                            
                            if "trabar" in desc_text.lower():
                                elementos_trabar.append((i, desc_text))
                            
                            # Búsqueda exacta con strip()
                            if desc_text == "Trabar Embargo":
                                self.logger.info(f"✓ 'Trabar Embargo' encontrado (exacto) en índice {i}")
                                self.logger.info("[✓ ESTRATEGIA FUNCIONÓ] 'Trabar Embargo' localizado - ejecutando clic")
                                rect = descendant.rectangle()
                                
                                if rect.width() > 0 and rect.height() > 0:
                                    click_x = (rect.left + rect.right) // 2
                                    click_y = (rect.top + rect.bottom) // 2
                                    self.logger.info(f"Coordenadas válidas: ({click_x}, {click_y})")
                                    
                                    # Guardar coordenadas para reutilizar después
                                    self.trabar_embargo_coords = (click_x, click_y)
                                    self.logger.info(f"✓ Coordenadas de 'Trabar Embargo' guardadas: {self.trabar_embargo_coords}")
                                    
                                    self.logger.info(f"Haciendo clic en: ({click_x}, {click_y})")
                                    pyautogui.click(click_x, click_y)
                                    time.sleep(1)
                                    self.logger.info(" Clic completado exitosamente")
                                    return True
                                else:
                                    # Intentar invoke si no tiene coordenadas válidas
                                    self.logger.info("Coordenadas inválidas, intentando invoke...")
                                    try:
                                        descendant.invoke()
                                        time.sleep(1)
                                        self.logger.info(" Invocado correctamente")
                                        return True
                                    except:
                                        pyautogui.press('return')
                                        time.sleep(1)
                                        self.logger.info(" Enter presionado")
                                        return True
                        
                        except Exception:
                            pass
                    
                    # Si no se encontró, mostrar debugging detallado
                    self.logger.warning("'Trabar Embargo' NO encontrado en descendientes")
                    self.logger.warning("=" * 70)
                    self.logger.warning("DEBUG: ELEMENTOS CON 'EMBARGO':")
                    self.logger.warning("=" * 70)
                    for idx, elem_text in elementos_embargo:
                        self.logger.warning(f"[{idx}] '{elem_text}'")
                    
                    if not elementos_embargo:
                        self.logger.warning("(Ninguno encontrado)")
                    
                    self.logger.warning("=" * 70)
                    self.logger.warning("DEBUG: ELEMENTOS CON 'TRABAR':")
                    self.logger.warning("=" * 70)
                    for idx, elem_text in elementos_trabar:
                        self.logger.warning(f"[{idx}] '{elem_text}'")
                    
                    if not elementos_trabar:
                        self.logger.warning("(Ninguno encontrado)")
                    
                    self.logger.warning("=" * 70)
                
                except Exception as e:
                    self.logger.error(f"Error iterando descendientes: {e}")
            
            return False
        
        except Exception as e:
            self.logger.error(f"Error en click_trabar_embargo: {e}")
            return False
    
    # NAVEGACIÓN EMBARGO
    
    def go_to_trabar_embargo(self) -> bool:
        """
        Navega a Proceso de Embargo → Trabar Embargo.
        Utiliza las funciones separadas click_proceso_embargo() y click_trabar_embargo().
        """
        self.logger.info("\n" + "=" * 70)
        self.logger.info("NAVEGANDO A TRABAR EMBARGO")
        self.logger.info("=" * 70)
        
        # PASO 1: Hacer clic en "Proceso de Embargo"
        if not self.click_proceso_embargo():
            self.logger.error("No se pudo hacer clic en 'Proceso de Embargo'")
            return False
        
        # PASO 2: Hacer clic en "Trabar Embargo"
        if not self.click_trabar_embargo():
            self.logger.error("No se pudo hacer clic en 'Trabar Embargo'")
            return False
        
        self.logger.info(" Navegación a Trabar Embargo completada")
        return True
    
    # IEI (INTERVENCIÓN)
    
    def click_trabar_intervencion(self) -> bool:
        """
        Busca y hace DOBLE CLIC en 'Trabar Intervención en Información' usando coordenadas.
        Similar al patrón que funciona en click_trabar_embargo().
        El elemento tiene espacios en blanco al final que deben eliminarse con strip().
        """
        self.logger.info("Buscando 'Trabar Intervención en Información' en el menú...")
        
        try:
            # IMPORTANTE: Esperar a que el menú se expanda completamente
            # (Trabar Embargo puede tardar en renderizar los submenu items de Intervención)
            # DSE funciona con este delay, pero IEI requiere más tiempo para renderizar
            time.sleep(1)
            
            desktop = Desktop(backend=MSAA_BACKEND)
            
            # Buscar ventana SIRAT
            app = None
            try:
                app = desktop.window(title_re=".*SIRAT.*")
                if not app.exists(timeout=2):
                    app = None
            except:
                app = None
            
            if not app:
                try:
                    app = desktop.active()
                except:
                    app = None
            
            if app:
                self.logger.info("Ventana encontrada, iterando descendientes...")
                
                try:
                    descendants = app.descendants()
                    self.logger.info(f"Total de descendientes: {len(descendants)}")
                    
                    # Iterar todos los descendientes y buscar "Trabar Intervención en Información"
                    for i, descendant in enumerate(descendants):
                        try:
                            desc_text = descendant.window_text().strip()  # ← IMPORTANTE: strip()
                            
                            # Log detallado de elementos que contienen "Intervención"
                            if "intervención" in desc_text.lower():
                                self.logger.info(f"[{i}] Elemento con 'Intervención': '{desc_text}'")
                            
                            # Búsqueda robusta: case-insensitive + strip() adicional
                            # Esto tolera espacios en blanco ocultos y variaciones de caso
                            desc_text_normalized = desc_text.lower().strip()
                            target_text_normalized = "trabar intervención en información".lower().strip()
                            
                            # PRIMERO: Búsqueda EXACTA (como en DSE)
                            if desc_text_normalized == target_text_normalized:
                                self.logger.info(f" 'Trabar Intervención en Información' encontrado (exacto) en índice {i}")
                                rect = descendant.rectangle()
                                
                                if rect.width() > 0 and rect.height() > 0:
                                    click_x = (rect.left + rect.right) // 2
                                    click_y = (rect.top + rect.bottom) // 2
                                    self.logger.info(f"Coordenadas válidas: ({click_x}, {click_y})")
                                    self.logger.info(f"Haciendo DOBLE CLIC en: ({click_x}, {click_y})")
                                    pyautogui.doubleClick(click_x, click_y)
                                    self.logger.info(" Esperando 1 segundo después del doble clic...")
                                    time.sleep(1)
                                    self.logger.info(" Presionando ENTER para confirmar selección...")
                                    pyautogui.press('return')
                                    self.logger.info(" Esperando 0.5 segundos antes de ingresar INTERVENTOR...")
                                    time.sleep(0.5)
                                    self.logger.info(" Doble clic y ENTER completados exitosamente")
                                    return True
                                else:
                                    # Intentar invoke si no tiene coordenadas válidas
                                    self.logger.info("Coordenadas inválidas, intentando invoke...")
                                    try:
                                        descendant.invoke()
                                        time.sleep(1)
                                        self.logger.info(" Invocado correctamente")
                                        return True
                                    except:
                                        pyautogui.press('return')
                                        time.sleep(1)
                                        self.logger.info(" Enter presionado")
                                        return True
                        
                        except Exception as e:
                            pass
                    
                    self.logger.warning("Match EXACTO: 'Trabar Intervención en Información' no encontrado")
                    self.logger.info("\n INTENTO 2: Buscando con palabras clave parciales...")
                    
                    # SEGUNDO INTENTO: Búsqueda parcial (contiene "intervención" Y "trabar")
                    for i, descendant in enumerate(descendants):
                        try:
                            desc_text = descendant.window_text().strip()
                            desc_lower = desc_text.lower()
                            
                            # Si contiene AMBAS palabras clave
                            if "intervención" in desc_lower and "trabar" in desc_lower:
                                self.logger.info(f" Match PARCIAL encontrado en [{i}]: '{desc_text}'")
                                self.logger.info(f"  → Utilizando este elemento como alternativa")
                                
                                rect = descendant.rectangle()
                                if rect.width() > 0 and rect.height() > 0:
                                    click_x = (rect.left + rect.right) // 2
                                    click_y = (rect.top + rect.bottom) // 2
                                    self.logger.info(f"Haciendo DOBLE CLIC en: ({click_x}, {click_y})")
                                    pyautogui.doubleClick(click_x, click_y)
                                    time.sleep(1)
                                    pyautogui.press('return')
                                    time.sleep(0.5)
                                    return True
                                else:
                                    try:
                                        descendant.invoke()
                                        time.sleep(1)
                                        return True
                                    except:
                                        pyautogui.press('return')
                                        time.sleep(1)
                                        return True
                        except:
                            pass
                    
                    # TERCER INTENTO: Debug listing
                    self.logger.warning("Match PARCIAL también falló. Listando elementos con 'trabar':")
                    found_any = False
                    for i, descendant in enumerate(descendants):
                        try:
                            desc_text = descendant.window_text().strip()
                            if "trabar" in desc_text.lower():
                                self.logger.info(f"  [{i}] '{desc_text}'")
                                found_any = True
                        except:
                            pass
                    
                    if not found_any:
                        self.logger.warning("   NO SE ENCONTRÓ NINGÚN ELEMENTO CON 'TRABAR'")
                        self.logger.info("  Listando primeros 20 elementos para debug profundo:")
                        for i in range(min(20, len(descendants))):
                            try:
                                desc_text = descendants[i].window_text().strip()
                                self.logger.info(f"    [{i}] '{desc_text}'")
                            except:
                                pass
                
                except Exception as e:
                    self.logger.warning(f"Error iterando: {e}")
            
            self.logger.warning("No se pudo encontrar 'Trabar Intervención en Información'")
            return False
        
        except Exception as e:
            self.logger.error(f"Error en click_trabar_intervencion: {str(e)}")
            return False
    
    def iei_enter_interventor(self, interventor: str) -> Outcome:
        """
        Ingresa código de INTERVENTOR con detección optimizada de errores.
        
        OPTIMIZACIONES:
        - Reduce sleep antes de detección (1s → 0.3s)
        - detect_interventor_error() ahora usa SIRAT (0.5s en lugar de 24s)
        - Total esperado: 0.3s + 0.5s = 0.8s (vs 25s antes)
        
        FLUJO:
        1. Espera 0.5s para renderizado del campo INTERVENTOR
        2. Digita INTERVENTOR
        3. TAB para pasar a PLAZO
        4. Espera 0.3s para que aparezca aviso si INTERVENTOR es incorrecto
        5. Detecta en SIRAT (0.5s timeout optimizado)
        6. Si hay error → SKIP_INTERVENTOR_INVALIDO
        7. Si OK → retorna OK_RC
        """
        try:
            self.logger.info(f"Ingresando INTERVENTOR: {interventor}")
            
            # Esperar un poco para que se renderice el campo
            time.sleep(0.5)
            
            # Digitar INTERVENTOR directamente (sin hacer clic en el campo)
            self.logger.info(f"Digitando INTERVENTOR: '{interventor}'")
            pyautogui.write(str(interventor), interval=0.05)
            time.sleep(0.3)
            
            # Presionar TAB para pasar al campo PLAZO
            self.logger.info("Presionando TAB para pasar al campo PLAZO...")
            pyautogui.press('tab')
            time.sleep(0.3)
            
            # OPTIMIZADO: Reducido de 1s a 0.3s (mensaje aparece rápido)
            # + detect_interventor_error() ahora busca en SIRAT (0.5s)
            self.logger.info("Detectando error de INTERVENTOR (0.3s espera + 0.5s búsqueda optimizada)...")
            time.sleep(0.3)
            
            # Detectar si hay error de interventor (SIRAT optimizado)
            int_err, int_msg = self.detect_interventor_error(timeout=0.5)
            if int_err:
                self.logger.warning(f"Error en interventor: {int_msg}")
                self.logger.info("Presionando ENTER para cerrar diálogo de error...")
                pyautogui.press('return')
                time.sleep(1)
                self.logger.info("Presionando ALT+C para cerrar ventana IEI...")
                pyautogui.hotkey('alt', 'c')
                time.sleep(1)
                # NOTA: NO llamar restart_embargo_flow() aquí
                # logica.py se encargará de llamarlo si has_active_expediente = True
                return Outcome.SKIP_INTERVENTOR_INVALIDO
            
            self.logger.info(f"INTERVENTOR ingresado correctamente")
            return Outcome.OK_RC
        
        except Exception as e:
            self.logger.error(f"Error ingresando interventor: {e}")
            return Outcome.FAIL_UI
    
    def iei_set_plazo_and_confirm(self, plazo: int) -> Tuple[Outcome, Optional[str]]:
        """
        Ingresa PLAZO y maneja avisos de confirmación.
        Retorna (Outcome, rc_number).
        
        FLUJO:
        1. Esperar 1s después de TAB (ya detectó error de INTERVENTOR en paso anterior)
        2. Digitar PLAZO directamente (sin búsqueda, confiando en TAB previo)
        3. RETURN para confirmar campo
        4. ALT+A para confirmar pantalla (aquí aparecen avisos: embargos, desea continuar, etc)
        5. Loop de detección de avisos y RC
        """
        try:
            self.logger.info(f"Ingresando PLAZO: {plazo}")
            
            # Esperar máximo 1s (INTERVENTOR ya fue validado en paso anterior)
            # Este tiempo es para que se renderice el campo PLAZO
            self.logger.info("Esperando 1s para renderizado de PLAZO...")
            time.sleep(1)
            
            # Digitar PLAZO directamente (sin búsqueda)
            # TAB del paso anterior ya lo debería tener seleccionado
            self.logger.info(f"Digitando PLAZO: '{plazo}'")
            pyautogui.write(str(plazo), interval=0.05)
            time.sleep(0.3)
            
            # RETURN para confirmar campo PLAZO
            self.logger.info("Presionando RETURN para confirmar PLAZO...")
            pyautogui.press('return')
            time.sleep(1)
            
            # Presionar ALT+A para confirmar pantalla completa
            # AQUÍ es donde aparecen los avisos (embargos, desea continuar, grabar resolución, RC)
            self.logger.info("Presionando ALT+A para confirmar pantalla...")
            pyautogui.hotkey('alt', 'a')
            time.sleep(0.8)
            
            # Procesar avisos de confirmación que pueden aparecer después de ALT+A
            # FLUJO SIMPLIFICADO SOLO RC (OPTIMIZADO):
            # - SOLO buscar detección de RC
            # - Si NO es RC aún → ALT+S para avanzar (saltará otros avisos)
            # - Continuar hasta encontrar RC o timeout
            
            max_reintentos_rc = 15  # Reintentos para encontrar RC
            intentos_rc = 0
            rc_number = None
            timeout_total = 30  # Timeout total en segundos

            start_time = time.time()
            while (intentos_rc < max_reintentos_rc) and (time.time() - start_time < timeout_total):
                intentos_rc += 1

                # ÚNICA búsqueda: Detectar mensaje de RC "Se grabó Resolución Coactiva con número..."
                # Timeout aumentado a 1.0s para dar tiempo a renderizado (antes era 0.5s insuficiente)
                rc_det, rc_num = self.detect_rc_message(timeout=1.0)
                if rc_det and rc_num:
                    #  RC ENCONTRADA
                    rc_number = rc_num
                    self.logger.info(f"  [{intentos_rc}]  RC DETECTADA (IEI): {rc_number}")
                    
                    # Presionar ENTER para aceptar/cerrar el mensaje de RC
                    self.logger.info("  Presionando ENTER para cerrar mensaje de RC...")
                    pyautogui.press('return')
                    time.sleep(1)

                    # RC encontrada y confirmada - retornar para siguiente expediente
                    # (Accesos → Cambio de Expediente se manejan en el workflow)
                    self.logger.info("  RC confirmada, pasando al siguiente expediente (IEI)...")
                    return (Outcome.OK_RC, rc_number)
                else:
                    #  No es RC aún → ALT+S para saltar este aviso
                    # Esto saltará cualquier otro aviso (embargos, desea continuar, grabar, etc.)
                    self.logger.info(f"  [{intentos_rc}] RC no detectada → ALT+S para saltar aviso...")
                    pyautogui.hotkey('alt', 's')
                    time.sleep(0.5)  # Sleep más corto para reintentar
                    
                    # Continuar loop para buscar RC nuevamente

            # Si llegamos aquí sin RC
            self.logger.warning(f"Completado (IEI) sin RC detectada (intentos={intentos_rc}, tiempo={time.time()-start_time:.1f}s)")
            if rc_number:
                return (Outcome.OK_RC, rc_number)
            else:
                return (Outcome.OK_RC, None)
        
        except Exception as e:
            self.logger.error(f"Error en iei_set_plazo_and_confirm: {e}")
            return (Outcome.FAIL_UI, None)
    
    # SELECCIÓN DE TIPO DE EMBARGO
    
    def select_embargo_type(self, tipo_medida: str) -> bool:
        """
        Selecciona el tipo de embargo (IEI o DSE) en 'Trabar Embargo'.
        
        Args:
            tipo_medida: "IEI" o "DSE"
        
        Returns:
            True si se seleccionó correctamente, False si hubo error
            
        REINTENTOS: 3 intentos con delays progresivos (a veces falla por timing de UI).
        """
        MAX_REINTENTOS = 3
        
        for intento in range(1, MAX_REINTENTOS + 1):
            try:
                tipo_upper = str(tipo_medida).strip().upper()
                
                if "IEI" in tipo_upper:
                    self.logger.info(f"[Intento {intento}/{MAX_REINTENTOS}] Seleccionando IEI (Intervención)...")
                    if self.click_trabar_intervencion():
                        return True
                    else:
                        self.logger.warning(f"Intento {intento}: No se pudo seleccionar IEI")
                        if intento < MAX_REINTENTOS:
                            time.sleep(0.5)
                            continue
                        return False
                elif "DSE" in tipo_upper:
                    self.logger.info(f"[Intento {intento}/{MAX_REINTENTOS}] Seleccionando DSE (Depósito)...")
                    if self.click_trabar_deposito():
                        return True
                    else:
                        self.logger.warning(f"Intento {intento}: No se pudo seleccionar DSE")
                        if intento < MAX_REINTENTOS:
                            time.sleep(0.5)
                            continue
                        return False
                else:
                    self.logger.error(f"Tipo de medida no válido: {tipo_medida}")
                    return False
            
            except Exception as e:
                self.logger.error(f"Intento {intento}: Error seleccionando tipo de embargo: {e}")
                if intento < MAX_REINTENTOS:
                    time.sleep(0.5)
                    continue
                return False
        
        return False
    
    # DSE (DEPÓSITO)
    
    def click_trabar_deposito(self) -> bool:
        """Hace doble clic en 'Trabar Depósito sin Extracción' usando patrón robusto.
        
        Basado en rsi_32_expinv.py con logging detallado para debug.
        REINTENTOS: 3 intentos con delays progresivos (a veces falla por timing de UI).
        """
        MAX_REINTENTOS = 3
        
        for intento in range(1, MAX_REINTENTOS + 1):
            try:
                self.logger.info(f"[Intento {intento}/{MAX_REINTENTOS}] Buscando 'Trabar Depósito sin Extracción'...")
                
                desktop = Desktop(backend=MSAA_BACKEND)
                
                # Buscar ventana SIRAT
                app = None
                try:
                    app = desktop.window(title_re=".*SIRAT.*")
                    if not app.exists(timeout=2):
                        app = None
                except Exception:
                    app = None
                
                if not app:
                    try:
                        app = desktop.active()
                    except Exception:
                        app = None
                
                if not app:
                    self.logger.error(f"Intento {intento}: No se encontró ventana SIRAT")
                    if intento < MAX_REINTENTOS:
                        time.sleep(0.5)
                        continue
                    return False
                
                self.logger.info("Ventana encontrada, iterando descendientes...")
                
                try:
                    descendants = app.descendants()
                    self.logger.info(f"Total de descendientes: {len(descendants)}")
                    
                    # ESTRATEGIA DE BÚSQUEDA PARA DSE:
                    # 1. Primero: buscar elemento que contenga 'sin extracción' (más específico)
                    # 2. Si no: buscar elemento que contenga 'depósito'
                    # 3. Si no: hacer debug listing
                    
                    found = False
                    
                    # INTENTO 1: Buscar "sin extracción" (lo más específico)
                    self.logger.info(f"  [ESTRATEGIA 1] Buscando elemento con 'sin extracción'...")
                    for i, descendant in enumerate(descendants):
                        try:
                            desc_text = descendant.window_text().strip()
                            desc_lower = desc_text.lower()
                            
                            # Log detallado de elementos que contienen "Depósito"
                            if "depósito" in desc_lower:
                                self.logger.info(f"[{i}] Elemento con 'Depósito': '{desc_text}'")
                            
                            # Búsqueda: contiene "sin extracción" (clave diferenciador)
                            if "sin extracción" in desc_lower:
                                self.logger.info(f" ENCONTRADO en [{i}]: '{desc_text}'")
                                self.logger.info("[ ESTRATEGIA 1 FUNCIONÓ] 'Trabar Depósito sin Extracción' encontrado")
                                found = True
                                rect = descendant.rectangle()
                                
                                if rect.width() > 0 and rect.height() > 0:
                                    click_x = (rect.left + rect.right) // 2
                                    click_y = (rect.top + rect.bottom) // 2
                                    self.logger.info(f"Coordenadas válidas: ({click_x}, {click_y})")
                                    self.logger.info(f"Haciendo DOBLE CLIC en: ({click_x}, {click_y})")
                                    pyautogui.doubleClick(click_x, click_y)
                                    self.logger.info(" Esperando 1 segundo después del doble clic...")
                                    time.sleep(1)
                                    self.logger.info(" Presionando ENTER para confirmar selección...")
                                    pyautogui.press('return')
                                    self.logger.info(" Esperando 0.5 segundos antes de escribir MONTO...")
                                    time.sleep(0.5)
                                    self.logger.info(" Doble clic y ENTER completados exitosamente")
                                    return True
                                else:
                                    # Intentar invoke si no tiene coordenadas válidas
                                    self.logger.info("Coordenadas inválidas, intentando invoke...")
                                    try:
                                        descendant.invoke()
                                        time.sleep(1)
                                        self.logger.info(" Invocado correctamente")
                                        return True
                                    except Exception:
                                        pyautogui.press('return')
                                        time.sleep(1)
                                        self.logger.info(" Enter presionado")
                                        return True
                        
                        except Exception:
                            pass
                    
                    # INTENTO 2: Si no encontró "sin extracción", buscar elemento que contenga "depósito"
                    if not found:
                        self.logger.warning(f"Intento {intento}: 'sin extracción' no encontrado")
                        self.logger.info(f"  [ESTRATEGIA 2] Buscando elemento con 'depósito'...")
                        
                        for i, descendant in enumerate(descendants):
                            try:
                                desc_text = descendant.window_text().strip()
                                desc_lower = desc_text.lower()
                                
                                # Buscar elementos que contengan "depósito"
                                if "depósito" in desc_lower:
                                    # Preferir "sin extracción" si está disponible, sino tomar cualquier depósito
                                    self.logger.info(f" ENCONTRADO en [{i}]: '{desc_text}'")
                                    self.logger.info("[ ESTRATEGIA 2 FUNCIONÓ] Elemento con 'depósito' encontrado")
                                    found = True
                                    rect = descendant.rectangle()
                                    
                                    if rect.width() > 0 and rect.height() > 0:
                                        click_x = (rect.left + rect.right) // 2
                                        click_y = (rect.top + rect.bottom) // 2
                                        self.logger.info(f"Haciendo DOBLE CLIC en: ({click_x}, {click_y})")
                                        pyautogui.doubleClick(click_x, click_y)
                                        time.sleep(1)
                                        pyautogui.press('return')
                                        time.sleep(0.5)
                                        return True
                                    else:
                                        try:
                                            descendant.invoke()
                                            time.sleep(1)
                                            return True
                                        except:
                                            pyautogui.press('return')
                                            time.sleep(1)
                                            return True
                            except:
                                pass
                        
                        # INTENTO 3: Si fallaron ambos intentos, mostrar debug
                        self.logger.warning("[ ESTRATEGIA 1 Y 2 FALLARON] Listando elementos con 'trabar' para debug:")
                        for i, descendant in enumerate(descendants):
                            try:
                                desc_text = descendant.window_text().strip()
                                if "trabar" in desc_text.lower():
                                    self.logger.info(f"  [{i}] '{desc_text}'")
                            except:
                                pass
                    
                    if intento < MAX_REINTENTOS:
                        time.sleep(0.5)
                        continue
                    return False
                
                except Exception as e:
                    self.logger.error(f"Intento {intento}: Error iterando: {e}")
                    if intento < MAX_REINTENTOS:
                        time.sleep(0.5)
                        continue
                    return False
            
            except Exception as e:
                self.logger.error(f"Intento {intento}: Error en click_trabar_deposito: {e}")
                if intento < MAX_REINTENTOS:
                    time.sleep(0.5)
                    continue
                return False
        
        self.logger.error("No se pudo encontrar 'Trabar Depósito sin Extracción' después de 3 intentos")
        return False
    
    def dse_set_monto_and_confirm(self, monto: float) -> Tuple[Outcome, Optional[str]]:
        """
        Ingresa MONTO y maneja dos escenarios posibles.
        
        FLUJO:
        1. Escribir MONTO en el campo ya seleccionado
        2. Presionar ALT+A para confirmar monto
        3. Verificar dos posibles escenarios:
        
        ESCENARIO 1 - MONTO MAYOR (Rechazado):
        - Detecta avisos de monto excesivo (puede haber 1 o 2, en cualquier orden):
          * "El monto ingresado excede en mas del [X]% el Saldo..." → ENTER
          * "El monto de embargo ingresado supera el saldo embargable..." → ENTER
        - Los números y valores pueden variar (porcentaje, saldo, etc)
        - Cuando no haya más avisos: ALT+C para cerrar
        - Retorna: SKIP_MONTO_MAYOR (se mapea a "MONTO MAYOR" en Excel)
        
        ESCENARIO 2 - MONTO VÁLIDO (Aceptado):
        - Secuencia de avisos de confirmación:
          1. "¿ Desea Continuar ?" → ALT+S
          2. "¿Desea Ud. grabar la Resolución?" → ALT+S
          3. "Se grabó la Resolución Coactiva con número [NNN]" → Extraer RC, ENTER, ALT+C
        - Retorna: (OK_RC, numero_rc_como_string)
        
        IMPORTANTE: RC se retorna como STRING para preservar 0s iniciales (ej: "00123456")
        """
        try:
            self.logger.info(f"Ingresando MONTO: {monto}")
            
            # PASO 1: Campo MONTO ya está listo y seleccionado después del doble clic + ENTER
            
            # PASO 2: Escribir MONTO
            monto_str = str(monto).replace(',', '.')
            self.logger.info(f"Paso 1: Escribiendo monto: {monto_str}")
            pyautogui.write(monto_str, interval=0.05)
            time.sleep(0.5)
            
            # PASO 3: Presionar ALT+A para confirmar monto
            self.logger.info("Paso 2: Presionando ALT+A para confirmar monto...")
            pyautogui.hotkey('alt', 'a')
            time.sleep(1)
            hubo_aviso_monto = False
            avisos_cerrados = 0
            max_avisos = 2  # Máximo 2 avisos posibles: 20% y supera saldo
            
            # FASE 1: Verificar si el monto es rechazado (ESCENARIO 1)
            self.logger.info("[FASE 1] Verificando avisos de monto excesivo...")
            while avisos_cerrados < max_avisos:
                # Buscar los dos tipos de avisos de monto excesivo
                aviso_20pct, msg_20pct = self.detect_aviso_monto_excede_20pct(timeout=0.5)
                aviso_supera, msg_supera = self.detect_aviso_monto_supera_saldo(timeout=0.5)
                
                # Si no hay ningún aviso, salir del loop
                if not aviso_20pct and not aviso_supera:
                    break
                
                if aviso_20pct:
                    hubo_aviso_monto = True
                    self.logger.warning(f"  Aviso 'excede 20%' detectado")
                    self.logger.info("  Presionando ENTER para cerrar...")
                    pyautogui.press('return')
                    time.sleep(1)
                    avisos_cerrados += 1
                
                if aviso_supera:
                    hubo_aviso_monto = True
                    self.logger.warning(f"  Aviso 'supera saldo' detectado")
                    self.logger.info("  Presionando ENTER para cerrar...")
                    pyautogui.press('return')
                    time.sleep(1)
                    avisos_cerrados += 1
            
            # Si hubo avisos de monto excesivo, retornar SKIP_MONTO_MAYOR
            if hubo_aviso_monto:
                self.logger.warning("Monto rechazado por excesivo. Presionando ALT+C para cancelar...")
                pyautogui.hotkey('alt', 'c')
                time.sleep(1)
                return (Outcome.SKIP_MONTO_MAYOR, None)
            
            self.logger.info(" Sin avisos de monto excesivo - continuando con ESCENARIO 2 (VÁLIDO)...")
            
            # FASE 2: Escenario 2 - Monto Válido (secuencia de confirmación)
            self.logger.info("[FASE 2] Procesando avisos de confirmación...")
            max_avisos_confirmacion = 3  # Máximo 3 avisos: Desea continuar? + Grabar resolución? + RC
            intentos = 0
            rc_number = None
            
            while intentos < max_avisos_confirmacion:
                intentos += 1
                
                # 1. "¿ Desea Continuar ?" (con espacios)
                desea_cont, desea_msg = self.detect_desea_continuar_aviso(timeout=0.5)
                if desea_cont:
                    self.logger.info(f"  [{intentos}] '¿ Desea Continuar ?' → ALT+S")
                    pyautogui.hotkey('alt', 's')
                    time.sleep(1)
                    continue
                
                # 2. "¿Desea Ud. grabar la Resolución?"
                grabar_det, grabar_msg = self.detect_desea_grabar_resolucion(timeout=0.5)
                if grabar_det:
                    self.logger.info(f"  [{intentos}] '¿Desea grabar Resolución?' → ALT+S")
                    pyautogui.hotkey('alt', 's')
                    time.sleep(1)
                    
                    # Después de este ALT+S, debería aparecer el mensaje de RC
                    self.logger.info("  Esperando mensaje de RC...")
                    rc_det, rc_num = self.detect_rc_message(timeout=3)
                    if rc_det and rc_num:
                        rc_number = rc_num
                        self.logger.info(f"   RC: {rc_number}")
                        self.logger.info("  ENTER para cerrar, luego ALT+C...")
                        pyautogui.press('return')
                        time.sleep(1)
                        pyautogui.hotkey('alt', 'c')
                        time.sleep(1)
                        return (Outcome.OK_RC, rc_number)
                    else:
                        self.logger.warning("  No se detectó RC, continuando...")
                        # Presionar ENTER de todas formas
                        pyautogui.press('return')
                        time.sleep(1)
                        pyautogui.hotkey('alt', 'c')
                        time.sleep(1)
                        return (Outcome.OK_RC, None)
                
                # 3. Mensaje de RC (en caso de que aparezca directamente)
                # Timeout aumentado a 1.0s para dar tiempo a renderizado (antes era 0.5s insuficiente)
                rc_det, rc_num = self.detect_rc_message(timeout=1.0)
                if rc_det and rc_num:
                    rc_number = rc_num
                    self.logger.info(f"  [{intentos}] RC detectada: {rc_number}")
                    pyautogui.press('return')
                    time.sleep(1)
                    pyautogui.hotkey('alt', 'c')
                    time.sleep(1)
                    return (Outcome.OK_RC, rc_number)
                
                # Si no se detectó ningún aviso
                self.logger.debug(f"  Intento {intentos}: Sin avisos nuevos")
                if intentos < max_avisos_confirmacion:
                    time.sleep(0.5)
            
            # Si llegamos aquí
            self.logger.warning("Completado (proceso finalizado sin RC del sistema)")
            return (Outcome.OK_RC, None)
        
        except Exception as e:
            self.logger.error(f"Error en dse_set_monto_and_confirm: {e}", exc_info=True)
            return (Outcome.FAIL_UI, None)
    
    # REINICIO DE FLUJO PARA SIGUIENTE EXPEDIENTE
    
    def click_proceso_embargo_for_restart(self) -> bool:
        """
        Hace clic en "Proceso de Embargo" desde el menú principal.
        Se usa como primer paso en el reinicio de flujo.
        """
        try:
            self.logger.info("  [1/3] Haciendo clic en 'Proceso de Embargo'...")
            
            desktop = Desktop(backend=MSAA_BACKEND)
            app = None
            try:
                app = desktop.window(title="SIRAT")
                if not app.exists(timeout=2):
                    app = None
            except:
                app = None
            
            if not app:
                try:
                    app = desktop.active()
                except:
                    return False
            
            if not app:
                return False
            
            # Buscar "Proceso de Embargo"
            try:
                descendants = app.descendants()
                for descendant in descendants:
                    try:
                        desc_text = descendant.window_text().strip()
                        if desc_text == "Proceso de Embargo":
                            rect = descendant.rectangle()
                            if rect and rect.width() > 0 and rect.height() > 0:
                                click_x = (rect.left + rect.right) // 2
                                click_y = (rect.top + rect.bottom) // 2
                                pyautogui.click(click_x, click_y)
                                time.sleep(1)
                                return True
                    except:
                        pass
            except:
                pass
            
            return False
        except Exception as e:
            self.logger.warning(f"Error en click_proceso_embargo_for_restart: {e}")
            return False
    
    def click_accesos_from_menu(self) -> bool:
        """
        Hace clic en "Accesos" después de expandir "Proceso de Embargo".
        Se usa como segundo paso en el reinicio de flujo.
        """
        try:
            self.logger.info("  [2/3] Haciendo clic en 'Accesos'...")
            
            desktop = Desktop(backend=MSAA_BACKEND)
            app = None
            try:
                app = desktop.window(title="SIRAT")
                if not app.exists(timeout=2):
                    app = None
            except:
                app = None
            
            if not app:
                try:
                    app = desktop.active()
                except:
                    return False
            
            if not app:
                return False
            
            # Buscar "Accesos"
            try:
                descendants = app.descendants()
                for descendant in descendants:
                    try:
                        desc_text = descendant.window_text().strip()
                        if desc_text == "Accesos":
                            rect = descendant.rectangle()
                            if rect and rect.width() > 0 and rect.height() > 0:
                                click_x = (rect.left + rect.right) // 2
                                click_y = (rect.top + rect.bottom) // 2
                                pyautogui.click(click_x, click_y)
                                time.sleep(1)
                                return True
                    except:
                        pass
            except:
                pass
            
            return False
        except Exception as e:
            self.logger.warning(f"Error en click_accesos_from_menu: {e}")
            return False
    
    def double_click_cambio_expediente(self) -> bool:
        """
        Hace DOBLE clic en "Cambio de Expediente" después de seleccionar "Accesos".
        Se usa como tercer paso en el reinicio de flujo.
        Esto prepara para ingresar el siguiente expediente.
        """
        try:
            self.logger.info("  [3/3] Haciendo doble clic en 'Cambio de Expediente'...")
            
            desktop = Desktop(backend=MSAA_BACKEND)
            app = None
            try:
                app = desktop.window(title="SIRAT")
                if not app.exists(timeout=2):
                    app = None
            except:
                app = None
            
            if not app:
                try:
                    app = desktop.active()
                except:
                    return False
            
            if not app:
                return False
            
            # Buscar "Cambio de Expediente"
            try:
                descendants = app.descendants()
                for descendant in descendants:
                    try:
                        desc_text = descendant.window_text().strip()
                        if desc_text == "Cambio de Expediente":
                            rect = descendant.rectangle()
                            if rect and rect.width() > 0 and rect.height() > 0:
                                click_x = (rect.left + rect.right) // 2
                                click_y = (rect.top + rect.bottom) // 2
                                self.logger.info(f"    Coordenadas: ({click_x}, {click_y})")
                                # Doble clic
                                pyautogui.doubleClick(click_x, click_y)
                                time.sleep(1.5)
                                return True
                    except:
                        pass
            except:
                pass
            
            return False
        except Exception as e:
            self.logger.warning(f"Error en double_click_cambio_expediente: {e}")
            return False
    
    def restart_embargo_flow(self) -> bool:
        """
        Reinicia el flujo de embargo para pasar al siguiente expediente.
        
        Secuencia:
        1. Click en "Proceso de Embargo"
        2. Click en "Accesos"
        3. Doble clic en "Cambio de Expediente"
        
        Se usa después de completar un expediente DSE (cuando ya se extrajo RC).
        
        Retorna: True si completó todos los pasos, False si hay error
        
        TODO: Usuario indicó que PODRÍA ser necesario agregar:
              if not self.click_trabar_embargo():
                  return False
              RAZÓN: Limpiar displacements del menú antes de acceder a Accesos
              ESTADO: Mantener comentado por ahora, activar si se detectan problemas
        """
        try:
            self.logger.info("\n[REINICIO] Reiniciando flujo para siguiente expediente...")
            
            if not self.click_proceso_embargo_for_restart():
                self.logger.warning("   No se pudo hacer clic en 'Proceso de Embargo'")
                return False
            
            if not self.click_accesos_from_menu():
                self.logger.warning("   No se pudo hacer clic en 'Accesos'")
                return False
            
            if not self.double_click_cambio_expediente():
                self.logger.warning("   No se pudo hacer doble clic en 'Cambio de Expediente'")
                return False
            
            self.logger.info("   Flujo reiniciado exitosamente")
            return True
        
        except Exception as e:
            self.logger.error(f"Error reiniciando flujo de embargo: {e}")
            return False
    
    def fill_monto(self, monto_value: str) -> bool:
        """
        Llena el campo de MONTO en el formulario (usado para Trabar Depósito sin Extracción - MEPECO).
        
        Flujo:
        1. Espera 0.5 segundos
        2. Digita el MONTO directamente
        3. Presiona ALT+A para confirmar
        4. Detecta si hay mensaje de aviso (puede variar según el monto)
        5. Retorna True si se completó exitosamente
        
        El campo MONTO aparece después de ejecutar "Trabar Depósito sin Extracción".
        """
        self.logger.info("Rellenando campo de MONTO...")
        
        try:
            # ============================================================
            # PASO 1: Esperar 0.5s y digitar MONTO
            # ============================================================
            self.logger.info("=" * 70)
            self.logger.info("PASO 1: Esperando 0.5s y digitando MONTO")
            self.logger.info("=" * 70)
            
            # Esperar 0.5 segundos antes de digitar MONTO
            self.logger.info("Esperando 0.5 segundos antes de digitar MONTO...")
            time.sleep(0.5)
            
            # Digitar MONTO directamente con intervalo entre caracteres
            self.logger.info(f"Digitando MONTO: '{monto_value}'")
            pyautogui.write(monto_value, interval=0.05)
            time.sleep(0.3)
            
            # ============================================================
            # PASO 2: Presionar ALT+A para confirmar
            # ============================================================
            self.logger.info("=" * 70)
            self.logger.info("PASO 2: Presionando ALT+A para confirmar MONTO")
            self.logger.info("=" * 70)
            
            self.logger.info("Presionando ALT+A...")
            pyautogui.hotkey('alt', 'a')
            time.sleep(1)
            self.logger.info(" ALT+A presionado correctamente")
            
            # ============================================================
            # PASO 3: Detectar mensaje de aviso del MONTO
            # ============================================================
            self.logger.info("=" * 70)
            self.logger.info("PASO 3: Detectando posible mensaje de aviso del MONTO")
            self.logger.info("=" * 70)
            
            # La detección de avisos se realiza en workflow.py/app_driver.py
            # mediante detect_monto_aviso() que es llamado después de fill_monto()
            self.logger.info("Aviso (si existe) será detectado en paso posterior")
            
            self.logger.info("=" * 70)
            self.logger.info(" CAMPO MONTO COMPLETADO EXITOSAMENTE")
            self.logger.info("=" * 70)
            
            return True
        
        except Exception as e:
            self.logger.error(f"Error en fill_monto: {str(e)}")
            return False
    
    # EXTRACCIÓN DE RC
    
    def _extract_rc_from_dialog(self) -> Optional[str]:
        """Busca mensaje de RC y extrae el número. Retorna string "XXXXX" o None."""
        try:
            desktop = Desktop(backend=MSAA_BACKEND)
            
            for element in self.iter_all_descendants():
                try:
                    text = str(element.element_info.name or "").lower()
                    
                    if "se grabó" in text and "resolución" in text and "número" in text:
                        # Encontrado el mensaje, extraer número
                        full_text = str(element.element_info.name or "")
                        
                        # Buscar la palabra "número" y extraer dígitos después
                        idx = full_text.lower().find("número")
                        if idx >= 0:
                            after_numero = full_text[idx + 6:]
                            # Extraer dígitos consecutivos
                            rc = ""
                            for char in after_numero:
                                if char.isdigit():
                                    rc += char
                                elif rc:  # Si ya tenemos dígitos y encontramos no-dígito, terminar
                                    break
                            
                            if rc:
                                return rc
                except Exception:
                    continue
            
            return None
        
        except Exception as e:
            self.logger.warning(f"Error extrayendo RC: {e}")
            return None
