const puppeteer = require('puppeteer')

const Exceljs = require('exceljs')

const fs = require('fs').promises

//Modulo para llama archivos del sistema
const os = require('os')

const path = require('path')

async function BusquedaGeneral() {

    let browser
    try {

        const exectutableChromeNavegador = await getChromeExecutablePath()

        browser = await puppeteer.launch({
            headless: false, //Permite que el navegador sea visible
            slowMo: 100, //Simulacro la escritura
            defaultViewport: false,
            args: [
                '--start-maximized', //Permite utilizar el navegador en pantalla completa
                '--no-sandbox',
                '--disable-setuid-sandbox',
                '--disable-infobars',
                '--disable-blink-features=AutomationControlled'
            ],
            executablePath: exectutableChromeNavegador
        })

        //Permite ejecutar el navegador nuevamente a partir de un cierre inesperado
        if (!browser || !browser.isConnected()) {
            browser = await puppeteer.launch();
            browser.on('disconnected', async () => {
                console.log('El navegador se ha cerrado. Reiniciando...');
                await BusquedaGeneral();
            });
        }

        const page = await browser.newPage()

        const RutaUsuario = path.resolve(process.cwd(), 'Credenciales', 'usuario.txt')

        const RutaContraseña = path.resolve(process.cwd(), 'Credenciales', 'contrasena.txt')

        const contenidoUsuario = await loadUserAccountFile(RutaUsuario)

        const contenidioContraseña = await loadUserAccountFile(RutaContraseña)

        const RutaArchivoExcel = path.resolve(process.cwd(), 'Data', 'Base_Contribuyente.xlsx')

        console.log('************ APP - SUNARP BÚSQUEDA GENERAL ************')

        // ================================================================================
        // FASE 0: LEER EXCEL Y PREPARAR ITERACIÓN
        // ================================================================================

        const NumeroTotalFilas = await FilasTotalesExcel(RutaArchivoExcel)

        // ================================================================================
        // FASE 1: AUTENTICACIÓN
        // ================================================================================

        await page.goto('https://sprl.sunarp.gob.pe/sprl/ingreso', { waitUntil: "networkidle0", timeout: 300000 })

        console.log('Navegando a SUNARP...')

        // Cerrar modal de bienvenida si existe
        try {
            const sidSunarp = await page.waitForSelector('button[aria-label="Close"]', { waitUntil: "networkidle0", timeout: 20000 })
            if (sidSunarp) {
                await page.keyboard.press('Escape')
            }
        } catch (error) {
            console.log('Modal no encontrado o ya cerrado')
            await page.keyboard.press('Escape')
        }

        // Click en botón "Ingresar"
        const btnIngresar = await page.waitForSelector('nz-form-control > div > div > div > button', { waitUntil: "networkidle0", timeout: 300000 })

        await btnIngresar.click()

        console.log(`Digitando Usuario...`)

        const usuario = await page.waitForSelector('input[name="username"]', { waitUntil: 'networkidle0', timeout: 300000 })

        await usuario.type(contenidoUsuario)

        console.log(`Digitando Contraseña...`)

        const contraseña = await page.waitForSelector('input[name="password"]', { waitUntil: 'networkidle0', timeout: 300000 })

        await contraseña.type(contenidioContraseña)

        console.log(`Iniciando Sesión...`)

        const btnInciarSesion = await page.waitForSelector('button[class="btn"]', { waitUntil: 'networkidle0', timeout: 300000 })

        await btnInciarSesion.click()

        // ================================================================================
        // FASE 2: SELECCIONAR BÚSQUEDA POR ÍNDICE
        // ================================================================================

        console.log('Seleccionando Búsqueda por Índice...')

        await page.waitForSelector('::-p-xpath(//app-main/nz-layout/nz-layout/nz-sider/div/app-sidenav-menu2/ul/li[1]/div[2]/ul/li/span[contains(text(),"Búsqueda")])', { waitUntil: 'networkidle0', timeout: 300000 })

        await page.$eval('::-p-xpath(//app-main/nz-layout/nz-layout/nz-sider/div/app-sidenav-menu2/ul/li[1]/div[2]/ul/li/span[contains(text(),"Búsqueda")])', elem => elem.click())

        // ================================================================================
        // FASE 3: SELECCIONAR TODAS LAS ZONAS REGISTRALES
        // ================================================================================

        console.log('Seleccionando todas las zonas registrales...')

        await page.waitForSelector('body > app-root > app-main > nz-layout > nz-layout > nz-content > app-busqueda-por-nombre-titular > div > div.card-list-body > div > div > nz-spin > div > div.ng-star-inserted > span > span > nz-card.ant-card.ant-card-bordered.ng-star-inserted > div > div > nz-transfer > nz-transfer-list:nth-child(1) > div.ant-transfer-list-header > label', { waitUntil: 'networkidle0', timeout: 300000 })

        await page.$eval('body > app-root > app-main > nz-layout > nz-layout > nz-content > app-busqueda-por-nombre-titular > div > div.card-list-body > div > div > nz-spin > div > div.ng-star-inserted > span > span > nz-card.ant-card.ant-card-bordered.ng-star-inserted > div > div > nz-transfer > nz-transfer-list:nth-child(1) > div.ant-transfer-list-header > label', elem => elem.click())

        console.log('Confirmar selección de zonas...')

        await page.$eval('body > app-root > app-main > nz-layout > nz-layout > nz-content > app-busqueda-por-nombre-titular > div > div.card-list-body > div > div > nz-spin > div > div.ng-star-inserted > span > span > nz-card.ant-card.ant-card-bordered.ng-star-inserted > div > div > nz-transfer > div > button:nth-child(2)', elem => elem.click())

        console.log('Esperando a que se carguen los formularios...')
        
        await new Promise(resolve => setTimeout(resolve, 3000))

        // ================================================================================
        // FASE 4 y 5: ITERAR POR CADA FILA DEL EXCEL
        // ================================================================================

        for (let indice = 2; indice <= NumeroTotalFilas; indice++) {

            console.log(`----> Número de Búsqueda ${indice - 1} de ${NumeroTotalFilas - 1} <----`)

            // Leer datos del Excel
            let valorRUC = await CapturarValorExcel(RutaArchivoExcel, indice, 'A')
            let valorNombre = await CapturarValorExcel(RutaArchivoExcel, indice, 'B')
            let valorNombreBusqueda = await CapturarValorExcel(RutaArchivoExcel, indice, 'C')
            let valorTipoSocial = await CapturarValorExcel(RutaArchivoExcel, indice, 'D')

            valorRUC = String(valorRUC).toLowerCase().trim()
            valorNombre = String(valorNombre).toLowerCase().trim()
            valorNombreBusqueda = String(valorNombreBusqueda).toUpperCase().trim()
            valorTipoSocial = String(valorTipoSocial).toLowerCase().trim()

            console.log(`RUC: ${valorRUC}, Nombre Búsqueda: ${valorNombreBusqueda}, Tipo: ${valorTipoSocial}`)

            // ================================================================================
            // SELECCIONAR ÁREA REGISTRAL SEGÚN TIPO SOCIAL
            // ================================================================================

            let selectorFinal, areaRegistralSeleccionada

            if (valorTipoSocial.includes('persona juridica') || valorTipoSocial.includes('empresa') || 
                valorTipoSocial.includes('sociedad') || valorTipoSocial.includes('sac') || 
                valorTipoSocial.includes('srl') || valorTipoSocial.includes('cooperativa')) {
                selectorFinal = '::-p-xpath(//nz-option-item[@title="Personas Juridicas"])'
                areaRegistralSeleccionada = 'Personas Jurídicas'
            } else if (valorTipoSocial.includes('vehicular')) {
                selectorFinal = '::-p-xpath(//nz-option-item[@title="Propiedad Vehicular"])'
                areaRegistralSeleccionada = 'Propiedad Vehicular'
            } else if (valorTipoSocial.includes('predial') || valorTipoSocial.includes('inmueble')) {
                selectorFinal = '::-p-xpath(//nz-option-item[@title="Propiedad Inmueble Predial"])'
                areaRegistralSeleccionada = 'Propiedad Inmueble Predial'
            } else {
                // Default por si no coincide con nada
                selectorFinal = '::-p-xpath(//nz-option-item[@title="Personas Juridicas"])'
                areaRegistralSeleccionada = 'Personas Jurídicas (default)'
            }

            console.log(`Seleccionando área registral: ${areaRegistralSeleccionada}...`)

            // Esperar el dropdown y seleccionar
            await page.waitForSelector('app-busqueda-por-nombre-titular nz-select nz-select-top-control', { waitUntil: 'networkidle0', timeout: 300000 })
            await page.$eval('app-busqueda-por-nombre-titular nz-select nz-select-top-control', elem => elem.click())

            await new Promise(resolve => setTimeout(resolve, 1000))

            // Seleccionar la opción
            await page.waitForSelector(selectorFinal, { waitUntil: 'networkidle0', timeout: 300000 })
            await page.$eval(selectorFinal, elem => elem.click())

            console.log('Área registral seleccionada')

            await new Promise(resolve => setTimeout(resolve, 1500))

            // ================================================================================
            // DETECTAR TIPO DE BÚSQUEDA Y LLENAR FORMULARIO
            // ================================================================================

            const esPersonaNatural = valorNombreBusqueda.includes('|')

            if (esPersonaNatural) {
                console.log('-> Detectado: PERSONA NATURAL')

                // Dividir el nombre
                const partes = valorNombreBusqueda.split('|')
                const apePat = partes[0].trim()
                const apeMat = partes[1].trim()
                const nombres = partes[2].trim()

                console.log(`Ape Paterno: ${apePat}, Ape Materno: ${apeMat}, Nombres: ${nombres}`)

                // Seleccionar selectores según área registral
                let selectorApePat, selectorApeMat, selectorNombres

                if (valorTipoSocial.includes('persona juridica') || valorTipoSocial.includes('empresa') || 
                    valorTipoSocial.includes('sociedad') || valorTipoSocial.includes('sac') || 
                    valorTipoSocial.includes('srl') || valorTipoSocial.includes('cooperativa')) {
                    // B. PERSONAS JURÍDICAS - PERSONA NATURAL
                    selectorApePat = 'input[name="apellidoPaterno"]'
                    selectorApeMat = 'input[name="apellidoMaterno"]'
                    selectorNombres = 'input[name="nombres"]'
                } else if (valorTipoSocial.includes('vehicular')) {
                    // C. PROPIEDAD VEHICULAR - PERSONA NATURAL
                    selectorApePat = 'input[name="apellidoPaterno"]'
                    selectorApeMat = 'input[name="apellidoMaterno"]'
                    selectorNombres = 'input[name="nombres"]'
                } else {
                    // A. PROPIEDAD INMUEBLE PREDIAL - PERSONA NATURAL (default)
                    selectorApePat = 'input[name="apellidoPaterno"]'
                    selectorApeMat = 'input[name="apellidoMaterno"]'
                    selectorNombres = 'input[name="nombres"]'
                }

                // Llenar campos de persona natural
                console.log(`← Iniciando digitación en campo: apellidoPaterno`)
                const campoApePat = await page.waitForSelector(selectorApePat, { waitUntil: 'networkidle0', timeout: 300000 })
                await campoApePat.click()
                await campoApePat.type(apePat)
                console.log(`   ✓ Digitación completada: "${apePat}"`)

                console.log(`← Iniciando digitación en campo: apellidoMaterno`)
                const campoApeMat = await page.waitForSelector(selectorApeMat, { waitUntil: 'networkidle0', timeout: 300000 })
                await campoApeMat.click()
                await campoApeMat.type(apeMat)
                console.log(`   ✓ Digitación completada: "${apeMat}"`)

                console.log(`← Iniciando digitación en campo: nombres`)
                const campoNombres = await page.waitForSelector(selectorNombres, { waitUntil: 'networkidle0', timeout: 300000 })
                await campoNombres.click()
                await campoNombres.type(nombres)
                console.log(`   ✓ Digitación completada: "${nombres}"`)

                // Presionar TAB + ENTER para buscar
                console.log('Presionando TAB + ENTER para Buscar (Persona Natural)...')
                await page.keyboard.press('Tab')
                await page.keyboard.press('Enter')

            } else {
                console.log('-> Detectado: PERSONA JURÍDICA / RAZÓN SOCIAL')

                const razonSocial = valorNombreBusqueda

                console.log(`Razón Social: ${razonSocial}`)

                // Seleccionar selectores según área registral
                let selectorRazonSocial

                if (valorTipoSocial.includes('persona juridica') || valorTipoSocial.includes('empresa') || 
                    valorTipoSocial.includes('sociedad') || valorTipoSocial.includes('sac') || 
                    valorTipoSocial.includes('srl') || valorTipoSocial.includes('cooperativa')) {
                    // B. PERSONAS JURÍDICAS - PERSONA JURÍDICA (usar segundo input)
                    selectorRazonSocial = 'input[name="razonSocial"]' // Se usará el segundo con page.$$
                } else if (valorTipoSocial.includes('vehicular')) {
                    // C. PROPIEDAD VEHICULAR - PERSONA JURÍDICA
                    selectorRazonSocial = 'input[name="razonSocial"]'
                } else {
                    // A. PROPIEDAD INMUEBLE PREDIAL - PERSONA JURÍDICA (default)
                    selectorRazonSocial = 'input[name="razonSocial"]'
                }

                // Llenar campo de razón social
                if (valorTipoSocial.includes('persona juridica') || valorTipoSocial.includes('empresa') || 
                    valorTipoSocial.includes('sociedad') || valorTipoSocial.includes('sac') || 
                    valorTipoSocial.includes('srl') || valorTipoSocial.includes('cooperativa')) {
                    // Para jurídicas: usar el SEGUNDO input[name="razonSocial"]
                    const camposRazonSocial = await page.$$(selectorRazonSocial)
                    console.log(`← Iniciando digitación en campo: razonSocial (segundo input)`)
                    if (camposRazonSocial.length > 1) {
                        await camposRazonSocial[1].click()
                        await camposRazonSocial[1].type(razonSocial)
                        console.log(`   ✓ Digitación completada en el segundo input`)
                    } else {
                        console.error('No se encontró el segundo campo de razón social')
                    }

                    // Presionar TAB + TAB + ENTER para buscar
                    console.log('Presionando TAB + TAB + ENTER para Buscar (Persona Jurídica)...')
                    await page.keyboard.press('Tab')
                    await page.keyboard.press('Tab')
                    await page.keyboard.press('Enter')
                } else {
                    // Para predial y vehicular: usar el primer input[name="razonSocial"]
                    console.log(`← Iniciando digitación en campo: razonSocial`)
                    const campoRazonSocial = await page.waitForSelector(selectorRazonSocial, { waitUntil: 'networkidle0', timeout: 300000 })
                    await campoRazonSocial.click()
                    await campoRazonSocial.type(razonSocial)
                    console.log(`   ✓ Digitación completada`)

                    // Presionar TAB + ENTER para buscar
                    console.log('Presionando TAB + ENTER para Buscar (Vehicular/Predial)...')
                    await page.keyboard.press('Tab')
                    await page.keyboard.press('Enter')
                }

            }

            console.log('Búsqueda completada, esperando resultados...')

            // Esperar un tiempo antes de continuar con la siguiente búsqueda
            await new Promise(resolve => setTimeout(resolve, 3000))

            if (indice == NumeroTotalFilas) {
                console.log('---> El Proceso a Finalizado Con Éxito <---')
                await browser.close()
            }
        }

    } catch (error) {
        console.error('Error al iniciar el navegador o realizar búsquedas:', error);
        // Cierra el navegador si hay un error
        if (browser) {
            await browser.close();
        }
        // Reintenta después de 15 segundos
        setTimeout(BusquedaGeneral, 15000);
    }

}

async function FilasTotalesExcel(ArchivoExcel) {

    const workbook = new Exceljs.Workbook();

    try {
        await workbook.xlsx.readFile(ArchivoExcel)
    } catch (error) {
        console.error(`Error leyendo archivo Excel: ${ArchivoExcel}`, error.message);
        throw error;
    }

    let obtenerNumeroFilas = 0;

    const worksheet = workbook.worksheets[0];

    if (!worksheet) {
        console.error('No se pudo obtener la hoja de trabajo del archivo Excel');
        throw new Error('Worksheet undefined');
    }

    worksheet.eachRow((row) => {

        if (row.hasValues) {
            obtenerNumeroFilas++;
        }
    })

    return obtenerNumeroFilas
}

async function CapturarValorExcel(ArchivoExcel, indiceFila, LetraVertical) {

    const workbook = new Exceljs.Workbook();

    try {
        await workbook.xlsx.readFile(ArchivoExcel)
    } catch (error) {
        console.error(`Error leyendo archivo Excel: ${ArchivoExcel}`, error.message);
        throw error;
    }

    const worksheet = workbook.worksheets[0];

    if (!worksheet) {
        console.error('No se pudo obtener la hoja de trabajo del archivo Excel');
        throw new Error('Worksheet undefined');
    }

    return worksheet.getCell(`${LetraVertical}${indiceFila}`).value

}

async function getChromeExecutablePath() {
    const pathA = 'C:\\Program Files\\Google\\Chrome\\Application\\chrome.exe';
    const pathB = 'C:\\Program Files (x86)\\Google\\Chrome\\Application\\chrome.exe';

    try {
        const pathAExists = await fs.access(pathA).then(() => true).catch(() => false);
        return pathAExists ? pathA : pathB;
    } catch (error) {
        console.error('Error al encontrar la ruta:', error);
        return null;
    }
}

async function loadUserAccountFile(archivoUsuario) {
    try {
        const textoUserAccount = await fs.readFile(archivoUsuario, 'utf-8');
        return textoUserAccount;
    } catch (error) {
        console.error('Error al leer el archivo:', error);
        return null;
    }
}

async function main() {
    await BusquedaGeneral()
}

main()
